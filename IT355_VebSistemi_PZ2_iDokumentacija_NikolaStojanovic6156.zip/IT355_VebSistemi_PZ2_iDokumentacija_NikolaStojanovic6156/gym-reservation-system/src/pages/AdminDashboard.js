import React, { useEffect, useState } from 'react';
import { Container, Typography, Tabs, Tab, Box, Table, TableHead, TableRow, TableCell, TableBody, IconButton, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Select, MenuItem, FormControl, InputLabel, Snackbar, Alert } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import { getUsers, updateUser, deleteUser, getClasses, createClass, updateClass, deleteClass, getTrainers, createTrainer, updateTrainer, deleteTrainer, getMemberships, createMembership } from '../services/api';

const AdminDashboard = () => {
  const [tab, setTab] = useState(0);
  const [users, setUsers] = useState([]);
  const [classes, setClasses] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [memberships, setMemberships] = useState([]);
  const [dialog, setDialog] = useState({ open: false, type: '', mode: 'add', data: {} });
  const [deleteDialog, setDeleteDialog] = useState({ open: false, type: '', id: null });
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const fetchAll = () => {
    getUsers().then(r => setUsers(r.data)).catch(() => {});
    getClasses().then(r => setClasses(r.data)).catch(() => {});
    getTrainers().then(r => setTrainers(r.data)).catch(() => {});
    getMemberships().then(r => setMemberships(r.data)).catch(() => {});
  };

  useEffect(() => { fetchAll(); }, []);

  const showSnack = (message, severity = 'success') => setSnackbar({ open: true, message, severity });

  const handleSave = async () => {
    const { type, mode, data } = dialog;
    try {
      if (type === 'class') {
        const payload = { ...data, trainer: data.trainerId ? { id: parseInt(data.trainerId) } : null };
        mode === 'add' ? await createClass(payload) : await updateClass(data.id, payload);
      } else if (type === 'trainer') {
        mode === 'add' ? await createTrainer(data) : await updateTrainer(data.id, data);
      } else if (type === 'user') {
        await updateUser(data.id, data);
      } else if (type === 'membership') {
        await createMembership({ userId: parseInt(data.userId), type: data.type, startDate: data.startDate });
      }
      showSnack('Sačuvano uspešno!');
      setDialog({ open: false, type: '', mode: 'add', data: {} });
      fetchAll();
    } catch (err) {
      showSnack(err.response?.data?.message || 'Greška', 'error');
    }
  };

  const handleDelete = async () => {
    const { type, id } = deleteDialog;
    try {
      if (type === 'user') await deleteUser(id);
      else if (type === 'class') await deleteClass(id);
      else if (type === 'trainer') await deleteTrainer(id);
      showSnack('Obrisano uspešno!');
      setDeleteDialog({ open: false, type: '', id: null });
      fetchAll();
    } catch (err) { showSnack('Greška pri brisanju', 'error'); }
  };

  const openEdit = (type, item) => {
    const data = type === 'class' ? { ...item, trainerId: item.trainer?.id || '' } : { ...item };
    setDialog({ open: true, type, mode: 'edit', data });
  };

  const openAdd = (type) => setDialog({ open: true, type, mode: 'add', data: {} });

  const updateField = (field, value) => setDialog(d => ({ ...d, data: { ...d.data, [field]: value } }));

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" sx={{ fontWeight: 700, mb: 3, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Admin Panel</Typography>
      <Tabs value={tab} onChange={(e, v) => setTab(v)} sx={{ mb: 3, '& .MuiTab-root': { color: 'rgba(255,255,255,0.6)' }, '& .Mui-selected': { color: '#ff6b35' } }}>
        <Tab label="Korisnici" /><Tab label="Časovi" /><Tab label="Treneri" /><Tab label="Članarine" />
      </Tabs>

      {/* USERS TAB */}
      {tab === 0 && (
        <Box>
          <Table>
            <TableHead><TableRow><TableCell>Email</TableCell><TableCell>Ime</TableCell><TableCell>Prezime</TableCell><TableCell>Rola</TableCell><TableCell>Akcije</TableCell></TableRow></TableHead>
            <TableBody>
              {users.map(u => (
                <TableRow key={u.id}>
                  <TableCell>{u.email}</TableCell><TableCell>{u.firstName}</TableCell><TableCell>{u.lastName}</TableCell><TableCell>{u.role}</TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => openEdit('user', u)}><EditIcon fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={() => setDeleteDialog({ open: true, type: 'user', id: u.id })}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}

      {/* CLASSES TAB */}
      {tab === 1 && (
        <Box>
          <Button startIcon={<AddIcon />} variant="contained" color="primary" sx={{ mb: 2 }} onClick={() => openAdd('class')}>Dodaj čas</Button>
          <Table>
            <TableHead><TableRow><TableCell>Naziv</TableCell><TableCell>Kategorija</TableCell><TableCell>Težina</TableCell><TableCell>Kapacitet</TableCell><TableCell>Trener</TableCell><TableCell>Akcije</TableCell></TableRow></TableHead>
            <TableBody>
              {classes.map(c => (
                <TableRow key={c.id}>
                  <TableCell>{c.name}</TableCell><TableCell>{c.category}</TableCell><TableCell>{c.difficulty}</TableCell><TableCell>{c.capacity}</TableCell>
                  <TableCell>{c.trainer ? `${c.trainer.firstName} ${c.trainer.lastName}` : '-'}</TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => openEdit('class', c)}><EditIcon fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={() => setDeleteDialog({ open: true, type: 'class', id: c.id })}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}

      {/* TRAINERS TAB */}
      {tab === 2 && (
        <Box>
          <Button startIcon={<AddIcon />} variant="contained" color="primary" sx={{ mb: 2 }} onClick={() => openAdd('trainer')}>Dodaj trenera</Button>
          <Table>
            <TableHead><TableRow><TableCell>Ime</TableCell><TableCell>Prezime</TableCell><TableCell>Specijalnost</TableCell><TableCell>Iskustvo</TableCell><TableCell>Akcije</TableCell></TableRow></TableHead>
            <TableBody>
              {trainers.map(t => (
                <TableRow key={t.id}>
                  <TableCell>{t.firstName}</TableCell><TableCell>{t.lastName}</TableCell><TableCell>{t.specialty}</TableCell><TableCell>{t.experienceYears} god.</TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => openEdit('trainer', t)}><EditIcon fontSize="small" /></IconButton>
                    <IconButton size="small" color="error" onClick={() => setDeleteDialog({ open: true, type: 'trainer', id: t.id })}><DeleteIcon fontSize="small" /></IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}

      {/* MEMBERSHIPS TAB */}
      {tab === 3 && (
        <Box>
          <Button startIcon={<AddIcon />} variant="contained" color="primary" sx={{ mb: 2 }} onClick={() => openAdd('membership')}>Dodaj članarinu</Button>
          <Table>
            <TableHead><TableRow><TableCell>Korisnik</TableCell><TableCell>Tip</TableCell><TableCell>Početak</TableCell><TableCell>Kraj</TableCell><TableCell>Cena</TableCell><TableCell>Status</TableCell></TableRow></TableHead>
            <TableBody>
              {memberships.map(m => (
                <TableRow key={m.id}>
                  <TableCell>{m.user?.email || '-'}</TableCell><TableCell>{m.type}</TableCell><TableCell>{m.startDate}</TableCell><TableCell>{m.endDate}</TableCell><TableCell>{m.price} RSD</TableCell><TableCell>{m.active ? '✅ Aktivna' : '❌ Istekla'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}

      {/* EDIT/ADD DIALOG */}
      <Dialog open={dialog.open} onClose={() => setDialog({ ...dialog, open: false })} maxWidth="sm" fullWidth>
        <DialogTitle>{dialog.mode === 'add' ? 'Dodaj' : 'Izmeni'} {dialog.type === 'class' ? 'čas' : dialog.type === 'trainer' ? 'trenera' : dialog.type === 'user' ? 'korisnika' : 'članarinu'}</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}>
          {dialog.type === 'user' && (<>
            <TextField label="Ime" value={dialog.data.firstName || ''} onChange={e => updateField('firstName', e.target.value)} />
            <TextField label="Prezime" value={dialog.data.lastName || ''} onChange={e => updateField('lastName', e.target.value)} />
            <TextField label="Email" value={dialog.data.email || ''} onChange={e => updateField('email', e.target.value)} />
            <FormControl><InputLabel>Rola</InputLabel><Select value={dialog.data.role || ''} label="Rola" onChange={e => updateField('role', e.target.value)}><MenuItem value="ROLE_USER">USER</MenuItem><MenuItem value="ROLE_ADMIN">ADMIN</MenuItem></Select></FormControl>
          </>)}
          {dialog.type === 'class' && (<>
            <TextField label="Naziv" value={dialog.data.name || ''} onChange={e => updateField('name', e.target.value)} />
            <TextField label="Opis" multiline rows={2} value={dialog.data.description || ''} onChange={e => updateField('description', e.target.value)} />
            <TextField label="Kapacitet" type="number" value={dialog.data.capacity || ''} onChange={e => updateField('capacity', parseInt(e.target.value))} />
            <TextField label="Trajanje (min)" type="number" value={dialog.data.durationMinutes || ''} onChange={e => updateField('durationMinutes', parseInt(e.target.value))} />
            <FormControl><InputLabel>Kategorija</InputLabel><Select value={dialog.data.category || ''} label="Kategorija" onChange={e => updateField('category', e.target.value)}>{['YOGA','CARDIO','STRENGTH','PILATES','CROSSFIT'].map(c=><MenuItem key={c} value={c}>{c}</MenuItem>)}</Select></FormControl>
            <FormControl><InputLabel>Težina</InputLabel><Select value={dialog.data.difficulty || ''} label="Težina" onChange={e => updateField('difficulty', e.target.value)}>{['BEGINNER','INTERMEDIATE','ADVANCED'].map(d=><MenuItem key={d} value={d}>{d}</MenuItem>)}</Select></FormControl>
            <TextField label="Raspored" value={dialog.data.schedule || ''} onChange={e => updateField('schedule', e.target.value)} />
            <FormControl><InputLabel>Trener</InputLabel><Select value={dialog.data.trainerId || ''} label="Trener" onChange={e => updateField('trainerId', e.target.value)}>{trainers.map(t=><MenuItem key={t.id} value={t.id}>{t.firstName} {t.lastName}</MenuItem>)}</Select></FormControl>
          </>)}
          {dialog.type === 'trainer' && (<>
            <TextField label="Ime" value={dialog.data.firstName || ''} onChange={e => updateField('firstName', e.target.value)} />
            <TextField label="Prezime" value={dialog.data.lastName || ''} onChange={e => updateField('lastName', e.target.value)} />
            <TextField label="Specijalnost" value={dialog.data.specialty || ''} onChange={e => updateField('specialty', e.target.value)} />
            <TextField label="Iskustvo (godina)" type="number" value={dialog.data.experienceYears || ''} onChange={e => updateField('experienceYears', parseInt(e.target.value))} />
            <TextField label="Biografija" multiline rows={2} value={dialog.data.bio || ''} onChange={e => updateField('bio', e.target.value)} />
            <TextField label="Telefon" value={dialog.data.phone || ''} onChange={e => updateField('phone', e.target.value)} />
          </>)}
          {dialog.type === 'membership' && (<>
            <FormControl><InputLabel>Korisnik</InputLabel><Select value={dialog.data.userId || ''} label="Korisnik" onChange={e => updateField('userId', e.target.value)}>{users.map(u=><MenuItem key={u.id} value={u.id}>{u.email}</MenuItem>)}</Select></FormControl>
            <FormControl><InputLabel>Tip</InputLabel><Select value={dialog.data.type || ''} label="Tip" onChange={e => updateField('type', e.target.value)}><MenuItem value="MONTHLY">MONTHLY</MenuItem><MenuItem value="QUARTERLY">QUARTERLY</MenuItem><MenuItem value="YEARLY">YEARLY</MenuItem></Select></FormControl>
            <TextField label="Datum početka" type="date" value={dialog.data.startDate || ''} onChange={e => updateField('startDate', e.target.value)} InputLabelProps={{ shrink: true }} />
          </>)}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialog({ ...dialog, open: false })}>Otkaži</Button>
          <Button variant="contained" color="primary" onClick={handleSave}>Sačuvaj</Button>
        </DialogActions>
      </Dialog>

      {/* DELETE DIALOG */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ ...deleteDialog, open: false })}>
        <DialogTitle>Potvrdite brisanje</DialogTitle>
        <DialogContent>Da li ste sigurni da želite da obrišete?</DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ ...deleteDialog, open: false })}>Ne</Button>
          <Button onClick={handleDelete} color="error" variant="contained">Da, obriši</Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
        <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
      </Snackbar>
    </Container>
  );
};

export default AdminDashboard;
