import React, { useEffect, useState } from 'react';
import { Container, Typography, Grid, Card, CardContent, Box, CircularProgress, Chip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { getMemberships, getActiveMembership } from '../services/api';

const plans = [
  { type: 'MONTHLY', label: 'Mesečna', price: '3.000 RSD', period: '/mesec', features: ['Pristup svim časovima', 'Osnovna oprema', 'Fleksibilan raspored'] },
  { type: 'QUARTERLY', label: 'Kvartalna', price: '7.500 RSD', period: '/3 meseca', features: ['Sve iz mesečne', 'Popust 17%', 'Pristup sauni'] },
  { type: 'YEARLY', label: 'Godišnja', price: '25.000 RSD', period: '/godina', features: ['Sve iz kvartalne', 'Popust 31%', 'Personalni plan', 'Prioritetna rezervacija'] },
];

const Memberships = () => {
  const [memberships, setMemberships] = useState([]);
  const [active, setActive] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getMemberships(), getActiveMembership()])
      .then(([memRes, actRes]) => { setMemberships(memRes.data); setActive(actRes.data || null); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 10 }}><CircularProgress /></Box>;

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Članarine</Typography>
      <Typography color="text.secondary" sx={{ mb: 4 }}>Izaberite plan koji vam odgovara</Typography>

      {active && (
        <Card sx={{ mb: 4, border: '2px solid #ff6b35', p: 1 }}>
          <CardContent>
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#ff6b35' }}>Aktivna članarina</Typography>
            <Typography>Tip: {active.type} | Važi do: {active.endDate}</Typography>
            <Chip label="AKTIVNA" color="success" size="small" sx={{ mt: 1 }} />
          </CardContent>
        </Card>
      )}

      <Grid container spacing={4} sx={{ mt: 2 }}>
        {plans.map((plan, i) => (
          <Grid item xs={12} md={4} key={plan.type}>
            <Card sx={{ textAlign: 'center', py: 4, px: 3, border: active?.type === plan.type ? '2px solid #ff6b35' : '1px solid rgba(255,255,255,0.05)', transition: 'transform 0.3s', '&:hover': { transform: 'translateY(-8px)' }, position: 'relative' }}>
              {i === 2 && <Chip label="NAJBOLJA VREDNOST" size="small" color="primary" sx={{ position: 'absolute', top: 16, right: 16 }} />}
              <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>{plan.label}</Typography>
              <Typography variant="h3" sx={{ fontWeight: 800, color: '#ff6b35' }}>{plan.price}</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>{plan.period}</Typography>
              {plan.features.map(f => (
                <Box key={f} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 1 }}>
                  <CheckCircleIcon sx={{ fontSize: 18, color: '#ff6b35' }} />
                  <Typography variant="body2">{f}</Typography>
                </Box>
              ))}
              <Typography variant="body2" color="text.secondary" sx={{ mt: 3 }}>Kontaktirajte admina za kupovinu</Typography>
            </Card>
          </Grid>
        ))}
      </Grid>

      {memberships.length > 0 && (
        <Box sx={{ mt: 6 }}>
          <Typography variant="h5" sx={{ fontWeight: 600, mb: 2 }}>Istorija članarina</Typography>
          {memberships.map(m => (
            <Card key={m.id} sx={{ mb: 2 }}>
              <CardContent sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography>{m.type} — {m.price} RSD</Typography>
                  <Typography variant="body2" color="text.secondary">{m.startDate} → {m.endDate}</Typography>
                </Box>
                <Chip label={m.active ? 'Aktivna' : 'Istekla'} color={m.active ? 'success' : 'default'} size="small" />
              </CardContent>
            </Card>
          ))}
        </Box>
      )}
    </Container>
  );
};

export default Memberships;
