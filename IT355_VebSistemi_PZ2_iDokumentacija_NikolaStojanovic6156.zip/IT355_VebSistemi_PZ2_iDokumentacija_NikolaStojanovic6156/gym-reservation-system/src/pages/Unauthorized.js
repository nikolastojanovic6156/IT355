import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import LockIcon from '@mui/icons-material/Lock';
import { Link } from 'react-router-dom';

const Unauthorized = () => (
  <Box sx={{ minHeight: '70vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
    <LockIcon sx={{ fontSize: 80, color: '#ff6b35', mb: 2 }} />
    <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>Pristup Odbijen</Typography>
    <Typography color="text.secondary" sx={{ mb: 3 }}>Nemate dozvolu za pristup ovoj stranici.</Typography>
    <Button component={Link} to="/" variant="contained" color="primary">Nazad na početnu</Button>
  </Box>
);

export default Unauthorized;
