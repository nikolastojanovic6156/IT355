import React, { useEffect, useState } from 'react';
import { Container, Typography, Card, CardContent, Grid, Chip, Button, Box, CircularProgress, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { getReservations, cancelReservation } from '../services/api';

const Reservations = () => {
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState(null);

  const fetchData = () => {
    setLoading(true);
    getReservations().then(res => { setReservations(res.data); setLoading(false); }).catch(() => setLoading(false));
  };

  useEffect(() => { fetchData(); }, []);

  const handleCancel = async () => {
    if (deleteId) {
      await cancelReservation(deleteId);
      setDeleteId(null);
      fetchData();
    }
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 10 }}><CircularProgress /></Box>;

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Moje Rezervacije</Typography>
      <Typography color="text.secondary" sx={{ mb: 4 }}>Pregled vaših rezervacija</Typography>
      {reservations.length === 0 ? (
        <Card sx={{ p: 4, textAlign: 'center' }}><Typography color="text.secondary">Nemate nijednu rezervaciju.</Typography></Card>
      ) : (
        <Grid container spacing={3}>
          {reservations.map(r => (
            <Grid item xs={12} sm={6} md={4} key={r.id}>
              <Card>
                <CardContent>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>{r.gymClass?.name || 'Čas'}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    {new Date(r.reservationDate).toLocaleString('sr-RS')}
                  </Typography>
                  <Chip label={r.status} size="small" color={r.status === 'ACTIVE' ? 'success' : 'error'} sx={{ mb: 2 }} />
                  {r.status === 'ACTIVE' && (
                    <Box sx={{ mt: 1 }}>
                      <Button variant="outlined" color="error" size="small" onClick={() => setDeleteId(r.id)}>Otkaži</Button>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
      <Dialog open={!!deleteId} onClose={() => setDeleteId(null)}>
        <DialogTitle>Potvrdite otkazivanje</DialogTitle>
        <DialogContent>Da li ste sigurni da želite da otkažete ovu rezervaciju?</DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteId(null)}>Ne</Button>
          <Button onClick={handleCancel} color="error" variant="contained">Da, otkaži</Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Reservations;
