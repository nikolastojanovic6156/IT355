import React, { useState } from 'react';
import { Box, Card, CardContent, Typography, TextField, Button, Alert } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError('Pogrešan email ili lozinka');
    }
  };

  return (
    <Box sx={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 2 }}>
      <Card sx={{ maxWidth: 420, width: '100%', p: 2 }}>
        <CardContent>
          <Typography variant="h4" align="center" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Prijava</Typography>
          <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 3 }}>Dobrodošli nazad</Typography>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <form onSubmit={handleSubmit}>
            <TextField fullWidth label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required sx={{ mb: 2 }} />
            <TextField fullWidth label="Lozinka" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required sx={{ mb: 3 }} />
            <Button fullWidth type="submit" variant="contained" size="large" sx={{ py: 1.5, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', '&:hover': { background: 'linear-gradient(135deg, #e55a2b, #e88f15)' } }}>Prijavi se</Button>
          </form>
          <Typography variant="body2" align="center" sx={{ mt: 2 }}>
            Nemate nalog? <Link to="/register" style={{ color: '#ff6b35' }}>Registrujte se</Link>
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Login;
