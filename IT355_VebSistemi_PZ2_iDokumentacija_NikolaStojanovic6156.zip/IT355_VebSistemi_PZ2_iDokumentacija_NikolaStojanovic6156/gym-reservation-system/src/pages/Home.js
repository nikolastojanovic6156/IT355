import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Container, Grid, Card, CardContent, Chip } from '@mui/material';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import GroupsIcon from '@mui/icons-material/Groups';
import ScheduleIcon from '@mui/icons-material/Schedule';
import StarIcon from '@mui/icons-material/Star';
import { Link } from 'react-router-dom';
import { getClasses } from '../services/api';

const features = [
  { icon: <FitnessCenterIcon sx={{ fontSize: 40 }} />, title: 'Personalizovani treninzi', desc: 'Programi prilagođeni vašim ciljevima i nivou fitnes iskustva.' },
  { icon: <GroupsIcon sx={{ fontSize: 40 }} />, title: 'Stručni treneri', desc: 'Sertifikovani treneri sa godinama iskustva u različitim disciplinama.' },
  { icon: <ScheduleIcon sx={{ fontSize: 40 }} />, title: 'Fleksibilan raspored', desc: 'Časovi dostupni u raznim terminima da se uklope u vaš raspored.' },
  { icon: <StarIcon sx={{ fontSize: 40 }} />, title: 'Premium oprema', desc: 'Najmodernija oprema za treniranje u savremenom ambijentu.' },
];

const Home = () => {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    getClasses().then(res => setClasses(res.data.slice(0, 3))).catch(() => {});
  }, []);

  return (
    <Box>
      {/* Hero */}
      <Box sx={{ minHeight: '80vh', display: 'flex', alignItems: 'center', background: 'linear-gradient(135deg, #0a0a0f 0%, #1a1a2e 50%, #16213e 100%)', position: 'relative', overflow: 'hidden' }}>
        <Box sx={{ position: 'absolute', top: '20%', right: '-5%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,107,53,0.15), transparent 70%)' }} />
        <Container maxWidth="lg">
          <Box sx={{ maxWidth: 700 }}>
            <Typography variant="h2" sx={{ fontWeight: 800, mb: 2, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', fontSize: { xs: '2.5rem', md: '3.5rem' } }}>
              Transformišite Svoj Fitnes Put
            </Typography>
            <Typography variant="h6" sx={{ color: 'rgba(255,255,255,0.7)', mb: 4, lineHeight: 1.6 }}>
              Pridružite se GymReserve zajednici i pristupite vrhunskim časovima, stručnim trenerima i fleksibilnom rasporedu koji se prilagođava vašem životnom stilu.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2 }}>
              <Button component={Link} to="/register" variant="contained" size="large" sx={{ px: 4, py: 1.5, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', '&:hover': { background: 'linear-gradient(135deg, #e55a2b, #e88f15)' } }}>
                Započnite
              </Button>
              <Button component={Link} to="/classes" variant="outlined" size="large" color="primary" sx={{ px: 4, py: 1.5 }}>
                Pogledajte Časove
              </Button>
            </Box>
          </Box>
        </Container>
      </Box>

      {/* Features */}
      <Container maxWidth="lg" sx={{ py: 10 }}>
        <Typography variant="h4" align="center" sx={{ fontWeight: 700, mb: 6 }}>Zašto izabrati nas</Typography>
        <Grid container spacing={4}>
          {features.map((f, i) => (
            <Grid item xs={12} sm={6} md={3} key={i}>
              <Card sx={{ textAlign: 'center', py: 4, px: 2, transition: 'transform 0.3s, box-shadow 0.3s', '&:hover': { transform: 'translateY(-8px)', boxShadow: '0 12px 40px rgba(255,107,53,0.15)' } }}>
                <Box sx={{ color: '#ff6b35', mb: 2 }}>{f.icon}</Box>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>{f.title}</Typography>
                <Typography variant="body2" color="text.secondary">{f.desc}</Typography>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* Classes Preview */}
      {classes.length > 0 && (
        <Box sx={{ bgcolor: 'rgba(22,22,30,0.5)', py: 10 }}>
          <Container maxWidth="lg">
            <Typography variant="h4" align="center" sx={{ fontWeight: 700, mb: 6 }}>Popularni Časovi</Typography>
            <Grid container spacing={4}>
              {classes.map((c) => (
                <Grid item xs={12} sm={6} md={4} key={c.id}>
                  <Card sx={{ transition: 'transform 0.3s', '&:hover': { transform: 'scale(1.03)' } }}>
                    <CardContent>
                      <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>{c.name}</Typography>
                      <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                        <Chip label={c.category} size="small" color="primary" />
                        <Chip label={c.difficulty} size="small" variant="outlined" />
                      </Box>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{c.description}</Typography>
                      <Typography variant="body2">⏱ {c.durationMinutes} min | 👥 Kapacitet: {c.capacity}</Typography>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
            <Box sx={{ textAlign: 'center', mt: 4 }}>
              <Button component={Link} to="/classes" variant="outlined" color="primary" size="large">Pogledajte sve časove</Button>
            </Box>
          </Container>
        </Box>
      )}
    </Box>
  );
};

export default Home;
