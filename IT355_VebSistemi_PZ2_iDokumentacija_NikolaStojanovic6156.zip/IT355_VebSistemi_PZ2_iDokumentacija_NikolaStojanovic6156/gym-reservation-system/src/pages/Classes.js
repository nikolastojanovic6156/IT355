import React, { useEffect, useState } from 'react';
import { Box, Typography, Container, Grid, Card, CardContent, Chip, Button, Snackbar, Alert, CircularProgress } from '@mui/material';
import { getClasses, createReservation } from '../services/api';
import { useAuth } from '../context/AuthContext';

const categories = ['ALL', 'YOGA', 'CARDIO', 'STRENGTH', 'PILATES', 'CROSSFIT'];
const difficultyColor = { BEGINNER: 'success', INTERMEDIATE: 'warning', ADVANCED: 'error' };

const Classes = () => {
  const [classes, setClasses] = useState([]);
  const [filter, setFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const { user } = useAuth();

  useEffect(() => {
    getClasses().then(res => { setClasses(res.data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const filtered = filter === 'ALL' ? classes : classes.filter(c => c.category === filter);

  const handleBook = async (classId) => {
    try {
      await createReservation(classId);
      setSnackbar({ open: true, message: 'Rezervacija uspešna!', severity: 'success' });
    } catch (err) {
      setSnackbar({ open: true, message: err.response?.data?.message || 'Greška pri rezervaciji', severity: 'error' });
    }
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 10 }}><CircularProgress /></Box>;

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Časovi</Typography>
      <Typography color="text.secondary" sx={{ mb: 4 }}>Pronađite savršen trening za sebe</Typography>
      <Box sx={{ display: 'flex', gap: 1, mb: 4, flexWrap: 'wrap' }}>
        {categories.map(cat => (
          <Chip key={cat} label={cat === 'ALL' ? 'Svi' : cat} onClick={() => setFilter(cat)} color={filter === cat ? 'primary' : 'default'} variant={filter === cat ? 'filled' : 'outlined'} sx={{ cursor: 'pointer' }} />
        ))}
      </Box>
      <Grid container spacing={3}>
        {filtered.map(c => (
          <Grid item xs={12} sm={6} md={4} key={c.id}>
            <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', transition: 'transform 0.3s, box-shadow 0.3s', '&:hover': { transform: 'translateY(-6px)', boxShadow: '0 8px 30px rgba(255,107,53,0.15)' } }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>{c.name}</Typography>
                <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
                  <Chip label={c.category} size="small" color="primary" />
                  <Chip label={c.difficulty} size="small" color={difficultyColor[c.difficulty] || 'default'} />
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{c.description}</Typography>
                <Typography variant="body2">⏱ {c.durationMinutes} min | 👥 {c.capacity} mesta</Typography>
                <Typography variant="body2" sx={{ mt: 0.5 }}>📅 {c.schedule}</Typography>
                {c.trainer && <Typography variant="body2" sx={{ mt: 0.5 }}>🏋️ {c.trainer.firstName} {c.trainer.lastName}</Typography>}
              </CardContent>
              {user && (
                <Box sx={{ p: 2, pt: 0 }}>
                  <Button fullWidth variant="contained" onClick={() => handleBook(c.id)} sx={{ background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)' }}>Rezerviši</Button>
                </Box>
              )}
            </Card>
          </Grid>
        ))}
      </Grid>
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
        <Alert severity={snackbar.severity} onClose={() => setSnackbar({ ...snackbar, open: false })}>{snackbar.message}</Alert>
      </Snackbar>
    </Container>
  );
};

export default Classes;
