import React, { useEffect, useState } from 'react';
import { Container, Typography, Grid, Card, CardContent, Avatar, Box, CircularProgress } from '@mui/material';
import { getTrainers } from '../services/api';

const Trainers = () => {
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getTrainers().then(res => { setTrainers(res.data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 10 }}><CircularProgress /></Box>;

  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Naši Treneri</Typography>
      <Typography color="text.secondary" sx={{ mb: 4 }}>Upoznajte naš stručni tim</Typography>
      <Grid container spacing={4}>
        {trainers.map(t => (
          <Grid item xs={12} sm={6} md={3} key={t.id}>
            <Card sx={{ textAlign: 'center', py: 4, px: 2, transition: 'transform 0.3s', '&:hover': { transform: 'scale(1.03)' }, borderTop: '3px solid #ff6b35' }}>
              <Avatar sx={{ width: 80, height: 80, mx: 'auto', mb: 2, bgcolor: '#ff6b35', fontSize: 28 }}>
                {t.firstName[0]}{t.lastName[0]}
              </Avatar>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>{t.firstName} {t.lastName}</Typography>
              <Typography variant="body2" color="primary" sx={{ mb: 1 }}>{t.specialty}</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{t.experienceYears} godina iskustva</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ fontSize: '0.8rem' }}>{t.bio}</Typography>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Trainers;
