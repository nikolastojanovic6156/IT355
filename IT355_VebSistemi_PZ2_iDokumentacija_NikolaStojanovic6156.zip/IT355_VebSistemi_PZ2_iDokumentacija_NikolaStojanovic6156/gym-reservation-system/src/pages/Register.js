import React, { useState } from 'react';
import { Box, Card, CardContent, Typography, TextField, Button, Alert } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Register = () => {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');
    try {
      await register(form.firstName, form.lastName, form.email, form.password);
      setSuccess('Registracija uspešna! Preusmeravanje na prijavu...');
      setTimeout(() => navigate('/login'), 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Greška pri registraciji');
    }
  };

  return (
    <Box sx={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center', p: 2 }}>
      <Card sx={{ maxWidth: 420, width: '100%', p: 2 }}>
        <CardContent>
          <Typography variant="h4" align="center" sx={{ fontWeight: 700, mb: 1, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Registracija</Typography>
          <Typography variant="body2" align="center" color="text.secondary" sx={{ mb: 3 }}>Kreirajte svoj nalog</Typography>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
          <form onSubmit={handleSubmit}>
            <TextField fullWidth label="Ime" name="firstName" value={form.firstName} onChange={handleChange} required sx={{ mb: 2 }} />
            <TextField fullWidth label="Prezime" name="lastName" value={form.lastName} onChange={handleChange} required sx={{ mb: 2 }} />
            <TextField fullWidth label="Email" name="email" type="email" value={form.email} onChange={handleChange} required sx={{ mb: 2 }} />
            <TextField fullWidth label="Lozinka" name="password" type="password" value={form.password} onChange={handleChange} required sx={{ mb: 3 }} />
            <Button fullWidth type="submit" variant="contained" size="large" sx={{ py: 1.5, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)' }}>Registruj se</Button>
          </form>
          <Typography variant="body2" align="center" sx={{ mt: 2 }}>
            Već imate nalog? <Link to="/login" style={{ color: '#ff6b35' }}>Prijavite se</Link>
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Register;
