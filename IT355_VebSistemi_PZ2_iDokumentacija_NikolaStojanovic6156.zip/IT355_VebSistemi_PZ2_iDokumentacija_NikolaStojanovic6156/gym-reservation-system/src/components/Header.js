import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, Button, Box, IconButton, Drawer, List, ListItem, ListItemText } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import FitnessCenterIcon from '@mui/icons-material/FitnessCenter';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/'); };

  const navLinks = [
    { label: 'Početna', path: '/' },
    { label: 'Časovi', path: '/classes' },
    { label: 'Treneri', path: '/trainers' },
  ];
  if (user) {
    navLinks.push({ label: 'Rezervacije', path: '/reservations' });
    navLinks.push({ label: 'Članarine', path: '/memberships' });
  }
  if (isAdmin()) {
    navLinks.push({ label: 'Admin', path: '/admin' });
  }

  return (
    <>
      <AppBar position="sticky" sx={{ background: 'rgba(10,10,15,0.85)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <Toolbar>
          <IconButton color="inherit" onClick={() => setMobileOpen(true)} sx={{ display: { md: 'none' }, mr: 1 }}>
            <MenuIcon />
          </IconButton>
          <FitnessCenterIcon sx={{ color: '#ff6b35', mr: 1 }} />
          <Typography variant="h6" component={Link} to="/" sx={{ flexGrow: 0, mr: 4, textDecoration: 'none', color: 'inherit', fontWeight: 700, background: 'linear-gradient(135deg, #ff6b35, #ff9f1c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            GymReserve
          </Typography>
          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' }, gap: 1 }}>
            {navLinks.map((link) => (
              <Button key={link.path} component={Link} to={link.path} color="inherit" sx={{ '&:hover': { color: '#ff6b35' } }}>
                {link.label}
              </Button>
            ))}
          </Box>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            {user ? (
              <>
                <Typography variant="body2" sx={{ display: { xs: 'none', sm: 'block' }, mr: 1 }}>{user.firstName}</Typography>
                <Button onClick={handleLogout} variant="outlined" size="small" color="primary">Odjavi se</Button>
              </>
            ) : (
              <>
                <Button component={Link} to="/login" variant="outlined" size="small" color="primary">Prijava</Button>
                <Button component={Link} to="/register" variant="contained" size="small" color="primary">Registracija</Button>
              </>
            )}
          </Box>
        </Toolbar>
      </AppBar>
      <Drawer anchor="left" open={mobileOpen} onClose={() => setMobileOpen(false)}>
        <Box sx={{ width: 250, bgcolor: '#16161e', height: '100%' }}>
          <List>
            {navLinks.map((link) => (
              <ListItem key={link.path} component={Link} to={link.path} onClick={() => setMobileOpen(false)} sx={{ color: '#e0e0e0' }}>
                <ListItemText primary={link.label} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
    </>
  );
};

export default Header;
