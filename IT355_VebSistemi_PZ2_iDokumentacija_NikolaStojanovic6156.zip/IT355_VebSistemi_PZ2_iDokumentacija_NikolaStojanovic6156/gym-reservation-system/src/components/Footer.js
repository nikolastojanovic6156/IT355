import React from 'react';
import { Box, Typography } from '@mui/material';

const Footer = () => (
  <Box component="footer" sx={{ py: 3, textAlign: 'center', borderTop: '1px solid rgba(255,255,255,0.05)', mt: 'auto', bgcolor: 'rgba(10,10,15,0.9)' }}>
    <Typography variant="body2" color="text.secondary">
      © 2024 GymReserve — Nikola Stojanović | IT355 Veb sistemi 2
    </Typography>
  </Box>
);

export default Footer;
