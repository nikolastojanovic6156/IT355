import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const login = (email, password) => api.post('/auth/login', { email, password });
export const register = (data) => api.post('/auth/register', data);

export const getClasses = () => api.get('/classes');
export const createClass = (data) => api.post('/classes', data);
export const updateClass = (id, data) => api.put(`/classes/${id}`, data);
export const deleteClass = (id) => api.delete(`/classes/${id}`);

export const getTrainers = () => api.get('/trainers');
export const createTrainer = (data) => api.post('/trainers', data);
export const updateTrainer = (id, data) => api.put(`/trainers/${id}`, data);
export const deleteTrainer = (id) => api.delete(`/trainers/${id}`);

export const getReservations = () => api.get('/reservations');
export const createReservation = (gymClassId) => api.post('/reservations', { gymClassId });
export const cancelReservation = (id) => api.delete(`/reservations/${id}`);

export const getMemberships = () => api.get('/memberships');
export const getActiveMembership = () => api.get('/memberships/active');
export const createMembership = (data) => api.post('/memberships', data);

export const getUsers = () => api.get('/users');
export const updateUser = (id, data) => api.put(`/users/${id}`, data);
export const deleteUser = (id) => api.delete(`/users/${id}`);

export default api;
