# Gym Reservation System

**IT354 – Projektni zadatak**  
**Student:** Nikola Stojanović 6156  
**Tema:** Sistem za rezervaciju termina u teretani

## 📋 Opis projekta

Full-stack web aplikacija za upravljanje rezervacijama u teretani. Sistem omogućava korisnicima da pregledaju i rezervišu termine za grupne treninge, dok administratori imaju potpun CRUD nad svim entitetima.

### Posebna funkcionalnost
**Auto-otkazivanje rezervacija za istekle članarine** — Sistem automatski (svakog sata putem `@Scheduled`) proverava članarine i otkazuje sve aktivne rezervacije korisnika čija je članarina istekla.

## 🏗️ Tehnologije

### Backend
- **Java 17** + **Spring Boot 3.2.5**
- **Spring Security** (JWT autentifikacija i autorizacija)
- **Spring Data JPA** (ORM)
- **H2 Database** (in-memory, za razvoj)
- **jjwt 0.12.5** (JSON Web Tokens)
- **Maven** (build tool)

### Frontend
- **React 19** (SPA)
- **Material UI** (UI komponente)
- **React Router** (navigacija)
- **Axios** (HTTP klijent)

## 📦 Struktura projekta

```
IT354_PZ_Nikola_Stojanovic_6156/
├── backend/                      # Spring Boot backend
│   ├── pom.xml
│   ├── mvnw                      # Maven wrapper
│   └── src/main/java/com/gym/reservation/
│       ├── GymReservationApplication.java
│       ├── entity/               # JPA entiteti (User, Trainer, GymClass, Reservation, Membership)
│       ├── repository/           # Spring Data repozitorijumi
│       ├── dto/                  # Data Transfer Objects
│       ├── service/              # Biznis logika + @Scheduled auto-otkazivanje
│       ├── controller/           # REST API kontroleri
│       ├── security/             # JWT + Spring Security konfiguracija
│       ├── exception/            # Globalni exception handling
│       └── config/               # DataInitializer (test podaci)
├── gym-reservation-system/       # React frontend
│   ├── package.json
│   └── src/
│       ├── App.js                # Routing
│       ├── context/AuthContext.js # Auth state management
│       ├── services/api.js       # Axios API layer
│       ├── components/           # Header, Footer, Layout, ProtectedRoute
│       └── pages/                # Home, Login, Register, Classes, Trainers, Reservations, Memberships, AdminDashboard
├── README.md
└── DOKUMENTACIJA.md
```

## 🚀 Pokretanje

### Preduslovi
- Java 17+
- Node.js 16+
- npm

### Backend
```bash
cd backend
./mvnw spring-boot:run
```
Backend će se pokrenuti na **http://localhost:8080**

### Frontend
```bash
cd gym-reservation-system
npm install
npm start
```
Frontend će se pokrenuti na **http://localhost:3000**

## 🔐 Test nalozi

| Uloga   | Email           | Lozinka    |
|---------|-----------------|------------|
| Admin   | admin@gym.com   | admin123   |
| Korisnik| user@gym.com    | user123    |
| Korisnik| ana@gym.com     | user123    |

## 📡 API Endpointi

### Autentifikacija
| Metoda | URL                | Opis          | Auth |
|--------|--------------------|---------------|------|
| POST   | /api/auth/login    | Prijava       | Ne   |
| POST   | /api/auth/register | Registracija  | Ne   |

### Časovi (GymClass)
| Metoda | URL                          | Opis              | Auth       |
|--------|------------------------------|--------------------|------------|
| GET    | /api/classes                 | Svi časovi         | Ne         |
| GET    | /api/classes/{id}            | Čas po ID          | Ne         |
| GET    | /api/classes/category/{cat}  | Po kategoriji      | Ne         |
| POST   | /api/classes                 | Kreiraj čas        | Da (JWT)   |
| PUT    | /api/classes/{id}            | Izmeni čas         | Da (JWT)   |
| DELETE | /api/classes/{id}            | Obriši čas         | Da (JWT)   |

### Treneri
| Metoda | URL                  | Opis              | Auth       |
|--------|----------------------|--------------------|------------|
| GET    | /api/trainers        | Svi treneri        | Ne         |
| GET    | /api/trainers/{id}   | Trener po ID       | Ne         |
| POST   | /api/trainers        | Kreiraj trenera    | Da (JWT)   |
| PUT    | /api/trainers/{id}   | Izmeni trenera     | Da (JWT)   |
| DELETE | /api/trainers/{id}   | Obriši trenera     | Da (JWT)   |

### Rezervacije
| Metoda | URL                      | Opis              | Auth       |
|--------|--------------------------|--------------------|------------|
| GET    | /api/reservations        | Moje rezervacije   | Da (JWT)   |
| POST   | /api/reservations        | Nova rezervacija   | Da (JWT)   |
| DELETE | /api/reservations/{id}   | Otkaži rezervaciju | Da (JWT)   |

### Članarine
| Metoda | URL                      | Opis                  | Auth       |
|--------|--------------------------|-----------------------|------------|
| GET    | /api/memberships         | Moje članarine        | Da (JWT)   |
| GET    | /api/memberships/active  | Aktivna članarina     | Da (JWT)   |
| POST   | /api/memberships         | Kreiraj članarinu     | Da (JWT)   |

### Korisnici (Admin)
| Metoda | URL                  | Opis              | Auth         |
|--------|----------------------|--------------------|--------------|
| GET    | /api/users           | Svi korisnici      | Da (ADMIN)   |
| GET    | /api/users/{id}      | Korisnik po ID     | Da (ADMIN)   |
| PUT    | /api/users/{id}      | Izmeni korisnika   | Da (ADMIN)   |
| DELETE | /api/users/{id}      | Obriši korisnika   | Da (ADMIN)   |

## ✅ Testovi

```bash
cd backend
./mvnw test
```

16 testova: 3 unit testa za ReservationService, 2 za MembershipService, 2 za UserService, 4 integraciona za AuthController, 3 za GymClassController, 2 za ReservationController.
