package com.gym.reservation.service;

import com.gym.reservation.entity.*;
import com.gym.reservation.exception.BadRequestException;
import com.gym.reservation.repository.GymClassRepository;
import com.gym.reservation.repository.MembershipRepository;
import com.gym.reservation.repository.ReservationRepository;
import com.gym.reservation.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReservationServiceTest {

    @Mock
    private ReservationRepository reservationRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private GymClassRepository gymClassRepository;

    @Mock
    private MembershipRepository membershipRepository;

    @InjectMocks
    private ReservationService reservationService;

    @Test
    void createReservation_WithActiveMembership_Success() {
        User user = new User("Marko", "Markovic", "user@gym.com", "pass", Role.ROLE_USER);
        user.setId(1L);

        GymClass gymClass = new GymClass();
        gymClass.setId(1L);
        gymClass.setName("Yoga Flow");

        Membership membership = new Membership();
        membership.setActive(true);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(gymClassRepository.findById(1L)).thenReturn(Optional.of(gymClass));
        when(membershipRepository.findByUserIdAndActiveTrue(1L)).thenReturn(Optional.of(membership));
        when(reservationRepository.save(any(Reservation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Reservation result = reservationService.createReservation(1L, 1L);

        assertNotNull(result);
        assertEquals(ReservationStatus.ACTIVE, result.getStatus());
        assertEquals(user, result.getUser());
        assertEquals(gymClass, result.getGymClass());
        verify(reservationRepository).save(any(Reservation.class));
    }

    @Test
    void createReservation_WithoutMembership_ThrowsException() {
        User user = new User();
        user.setId(1L);
        GymClass gymClass = new GymClass();
        gymClass.setId(1L);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(gymClassRepository.findById(1L)).thenReturn(Optional.of(gymClass));
        when(membershipRepository.findByUserIdAndActiveTrue(1L)).thenReturn(Optional.empty());

        assertThrows(BadRequestException.class, () ->
                reservationService.createReservation(1L, 1L));

        verify(reservationRepository, never()).save(any());
    }

    @Test
    void cancelReservation_Success() {
        Reservation reservation = new Reservation();
        reservation.setId(1L);
        reservation.setStatus(ReservationStatus.ACTIVE);

        when(reservationRepository.findById(1L)).thenReturn(Optional.of(reservation));
        when(reservationRepository.save(any(Reservation.class))).thenAnswer(invocation -> invocation.getArgument(0));

        reservationService.cancelReservation(1L);

        assertEquals(ReservationStatus.CANCELLED, reservation.getStatus());
        verify(reservationRepository).save(reservation);
    }
}
