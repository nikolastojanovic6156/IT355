package com.gym.reservation.service;

import com.gym.reservation.entity.Role;
import com.gym.reservation.entity.User;
import com.gym.reservation.exception.ResourceNotFoundException;
import com.gym.reservation.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void getAllUsers_ReturnsUserList() {
        User user1 = new User("Marko", "Markovic", "marko@gym.com", "pass", Role.ROLE_USER);
        User user2 = new User("Ana", "Anic", "ana@gym.com", "pass", Role.ROLE_USER);

        when(userRepository.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<User> result = userService.getAllUsers();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Marko", result.get(0).getFirstName());
    }

    @Test
    void getUserById_NotFound_ThrowsResourceNotFoundException() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () ->
                userService.getUserById(99L));
    }
}
