package com.gym.reservation.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gym.reservation.dto.LoginRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class GymClassControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void getClasses_WithoutAuth_ReturnsOk() throws Exception {
        mockMvc.perform(get("/api/classes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].name").exists());
    }

    @Test
    void createClass_WithoutAuth_ReturnsForbidden() throws Exception {
        String classJson = "{\"name\":\"New Class\",\"description\":\"Test\",\"capacity\":10,\"durationMinutes\":30,\"category\":\"YOGA\",\"difficulty\":\"BEGINNER\",\"schedule\":\"Monday 10:00\"}";

        mockMvc.perform(post("/api/classes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(classJson))
                .andExpect(status().isForbidden());
    }

    @Test
    void createClass_WithAdminAuth_ReturnsOk() throws Exception {
        // First, login as admin to get token
        LoginRequest loginRequest = new LoginRequest("admin@gym.com", "admin123");
        MvcResult loginResult = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode loginResponse = objectMapper.readTree(loginResult.getResponse().getContentAsString());
        String token = loginResponse.get("token").asText();

        // Then create a class with the admin token
        String classJson = "{\"name\":\"Test Class\",\"description\":\"Integration test class\",\"capacity\":10,\"durationMinutes\":30,\"category\":\"YOGA\",\"difficulty\":\"BEGINNER\",\"schedule\":\"Monday 10:00\"}";

        mockMvc.perform(post("/api/classes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", "Bearer " + token)
                        .content(classJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Test Class"));
    }
}
