package com.gym.reservation.service;

import com.gym.reservation.dto.MembershipRequest;
import com.gym.reservation.entity.*;
import com.gym.reservation.repository.MembershipRepository;
import com.gym.reservation.repository.ReservationRepository;
import com.gym.reservation.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MembershipServiceTest {

    @Mock
    private MembershipRepository membershipRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ReservationRepository reservationRepository;

    @InjectMocks
    private MembershipService membershipService;

    @Test
    void createMembership_Monthly_SetsCorrectEndDateAndPrice() {
        User user = new User("Marko", "Markovic", "user@gym.com", "pass", Role.ROLE_USER);
        user.setId(1L);

        MembershipRequest request = new MembershipRequest(1L, "MONTHLY", LocalDate.of(2024, 1, 1));

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(membershipRepository.save(any(Membership.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Membership result = membershipService.createMembership(request);

        assertNotNull(result);
        assertEquals(MembershipType.MONTHLY, result.getType());
        assertEquals(LocalDate.of(2024, 2, 1), result.getEndDate());
        assertEquals(3000.0, result.getPrice());
        assertTrue(result.getActive());
    }

    @Test
    void checkExpiredMemberships_DeactivatesExpiredAndCancelsReservations() {
        User user = new User("Test", "User", "test@gym.com", "pass", Role.ROLE_USER);
        user.setId(1L);

        Membership expiredMembership = new Membership();
        expiredMembership.setId(1L);
        expiredMembership.setUser(user);
        expiredMembership.setActive(true);
        expiredMembership.setEndDate(LocalDate.now().minusDays(1));

        Reservation activeReservation = new Reservation();
        activeReservation.setId(1L);
        activeReservation.setStatus(ReservationStatus.ACTIVE);

        when(membershipRepository.findByActiveTrueAndEndDateBefore(any(LocalDate.class)))
                .thenReturn(List.of(expiredMembership));
        when(reservationRepository.findByUserIdAndStatus(1L, ReservationStatus.ACTIVE))
                .thenReturn(List.of(activeReservation));
        when(membershipRepository.save(any())).thenAnswer(i -> i.getArgument(0));
        when(reservationRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        membershipService.checkExpiredMemberships();

        assertFalse(expiredMembership.getActive());
        assertEquals(ReservationStatus.CANCELLED, activeReservation.getStatus());
        verify(membershipRepository).save(expiredMembership);
        verify(reservationRepository).save(activeReservation);
    }
}
