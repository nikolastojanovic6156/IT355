package com.gym.reservation.entity;

public enum MembershipType {
    MONTHLY,
    QUARTERLY,
    YEARLY
}
