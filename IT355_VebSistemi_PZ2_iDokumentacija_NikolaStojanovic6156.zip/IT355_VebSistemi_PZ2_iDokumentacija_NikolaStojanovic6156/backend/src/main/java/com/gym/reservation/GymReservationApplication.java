package com.gym.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class GymReservationApplication {

    public static void main(String[] args) {
        SpringApplication.run(GymReservationApplication.class, args);
    }
}
