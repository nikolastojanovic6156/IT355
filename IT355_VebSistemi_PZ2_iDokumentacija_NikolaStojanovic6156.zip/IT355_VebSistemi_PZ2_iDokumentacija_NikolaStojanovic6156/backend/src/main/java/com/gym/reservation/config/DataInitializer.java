package com.gym.reservation.config;

import com.gym.reservation.entity.*;
import com.gym.reservation.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final TrainerRepository trainerRepository;
    private final GymClassRepository gymClassRepository;
    private final ReservationRepository reservationRepository;
    private final MembershipRepository membershipRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, TrainerRepository trainerRepository,
                           GymClassRepository gymClassRepository, ReservationRepository reservationRepository,
                           MembershipRepository membershipRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.trainerRepository = trainerRepository;
        this.gymClassRepository = gymClassRepository;
        this.reservationRepository = reservationRepository;
        this.membershipRepository = membershipRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        // Create users
        User admin = new User("Admin", "Admin", "admin@gym.com",
                passwordEncoder.encode("admin123"), Role.ROLE_ADMIN);
        admin = userRepository.save(admin);

        User user1 = new User("Marko", "Markovic", "user@gym.com",
                passwordEncoder.encode("user123"), Role.ROLE_USER);
        user1 = userRepository.save(user1);

        User user2 = new User("Ana", "Anic", "ana@gym.com",
                passwordEncoder.encode("user123"), Role.ROLE_USER);
        user2 = userRepository.save(user2);

        // Create trainers
        Trainer trainer1 = new Trainer("Nikola", "Petrovic", "Strength Training", 8,
                "Certified strength and conditioning specialist with 8 years of experience.", "+381601234567");
        trainer1 = trainerRepository.save(trainer1);

        Trainer trainer2 = new Trainer("Jelena", "Jovic", "Yoga", 5,
                "Registered yoga teacher specializing in Vinyasa and Hatha yoga.", "+381601234568");
        trainer2 = trainerRepository.save(trainer2);

        Trainer trainer3 = new Trainer("Stefan", "Ilic", "Cardio", 6,
                "High-intensity interval training expert and marathon runner.", "+381601234569");
        trainer3 = trainerRepository.save(trainer3);

        Trainer trainer4 = new Trainer("Milica", "Djordjevic", "Pilates", 4,
                "Pilates instructor focused on core stability and rehabilitation.", "+381601234570");
        trainer4 = trainerRepository.save(trainer4);

        // Create gym classes
        GymClass class1 = new GymClass("Power Lifting", "Build raw strength with compound movements including squats, deadlifts, and bench press.",
                15, 60, "STRENGTH", "ADVANCED", "Ponedeljak 10:00, Sreda 10:00", trainer1);
        class1 = gymClassRepository.save(class1);

        GymClass class2 = new GymClass("Yoga Flow", "Gentle flowing sequences to improve flexibility, balance, and mindfulness.",
                20, 45, "YOGA", "BEGINNER", "Utorak 08:00, Cetvrtak 08:00", trainer2);
        class2 = gymClassRepository.save(class2);

        GymClass class3 = new GymClass("HIIT Cardio", "High-intensity interval training to maximize calorie burn and cardiovascular fitness.",
                25, 30, "CARDIO", "INTERMEDIATE", "Ponedeljak 18:00, Petak 18:00", trainer3);
        gymClassRepository.save(class3);

        GymClass class4 = new GymClass("Pilates Core", "Core-focused Pilates exercises for stability, posture, and body awareness.",
                15, 50, "PILATES", "BEGINNER", "Sreda 17:00, Petak 09:00", trainer4);
        gymClassRepository.save(class4);

        GymClass class5 = new GymClass("CrossFit WOD", "Workout of the Day combining weightlifting, gymnastics, and metabolic conditioning.",
                12, 60, "CROSSFIT", "ADVANCED", "Utorak 19:00, Cetvrtak 19:00", trainer1);
        gymClassRepository.save(class5);

        GymClass class6 = new GymClass("Morning Yoga", "Start your day with energizing sun salutations and gentle stretches.",
                20, 60, "YOGA", "BEGINNER", "Ponedeljak 07:00, Sreda 07:00, Petak 07:00", trainer2);
        gymClassRepository.save(class6);

        // Create membership for user1
        Membership membership = new Membership(user1, MembershipType.MONTHLY,
                LocalDate.now(), LocalDate.now().plusDays(30), true, 3000.0);
        membershipRepository.save(membership);

        // Create reservations
        Reservation reservation1 = new Reservation(user1, class1,
                LocalDateTime.now(), ReservationStatus.ACTIVE);
        reservationRepository.save(reservation1);

        Reservation reservation2 = new Reservation(user1, class2,
                LocalDateTime.now(), ReservationStatus.ACTIVE);
        reservationRepository.save(reservation2);

        System.out.println("=== Test data initialized ===");
        System.out.println("Admin: admin@gym.com / admin123");
        System.out.println("User: user@gym.com / user123");
        System.out.println("User: ana@gym.com / user123");
    }
}
