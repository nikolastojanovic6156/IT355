package com.gym.reservation.service;

import com.gym.reservation.entity.GymClass;
import com.gym.reservation.entity.Trainer;
import com.gym.reservation.exception.ResourceNotFoundException;
import com.gym.reservation.repository.GymClassRepository;
import com.gym.reservation.repository.TrainerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class GymClassService {

    private final GymClassRepository gymClassRepository;
    private final TrainerRepository trainerRepository;

    public GymClassService(GymClassRepository gymClassRepository, TrainerRepository trainerRepository) {
        this.gymClassRepository = gymClassRepository;
        this.trainerRepository = trainerRepository;
    }

    public List<GymClass> getAllClasses() {
        return gymClassRepository.findAll();
    }

    public GymClass getClassById(Long id) {
        return gymClassRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found with id: " + id));
    }

    public List<GymClass> getClassesByCategory(String category) {
        return gymClassRepository.findByCategory(category);
    }

    @Transactional
    public GymClass createClass(GymClass gymClass) {
        if (gymClass.getTrainer() != null && gymClass.getTrainer().getId() != null) {
            Trainer trainer = trainerRepository.findById(gymClass.getTrainer().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Trainer not found"));
            gymClass.setTrainer(trainer);
        }
        return gymClassRepository.save(gymClass);
    }

    @Transactional
    public GymClass updateClass(Long id, GymClass classDetails) {
        GymClass gymClass = getClassById(id);
        gymClass.setName(classDetails.getName());
        gymClass.setDescription(classDetails.getDescription());
        gymClass.setCapacity(classDetails.getCapacity());
        gymClass.setDurationMinutes(classDetails.getDurationMinutes());
        gymClass.setCategory(classDetails.getCategory());
        gymClass.setDifficulty(classDetails.getDifficulty());
        gymClass.setSchedule(classDetails.getSchedule());
        if (classDetails.getTrainer() != null && classDetails.getTrainer().getId() != null) {
            Trainer trainer = trainerRepository.findById(classDetails.getTrainer().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Trainer not found"));
            gymClass.setTrainer(trainer);
        }
        return gymClassRepository.save(gymClass);
    }

    @Transactional
    public void deleteClass(Long id) {
        GymClass gymClass = getClassById(id);
        gymClassRepository.delete(gymClass);
    }
}
