package com.gym.reservation.service;

import com.gym.reservation.entity.*;
import com.gym.reservation.exception.BadRequestException;
import com.gym.reservation.exception.ResourceNotFoundException;
import com.gym.reservation.repository.GymClassRepository;
import com.gym.reservation.repository.MembershipRepository;
import com.gym.reservation.repository.ReservationRepository;
import com.gym.reservation.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final UserRepository userRepository;
    private final GymClassRepository gymClassRepository;
    private final MembershipRepository membershipRepository;

    public ReservationService(ReservationRepository reservationRepository, UserRepository userRepository,
                              GymClassRepository gymClassRepository, MembershipRepository membershipRepository) {
        this.reservationRepository = reservationRepository;
        this.userRepository = userRepository;
        this.gymClassRepository = gymClassRepository;
        this.membershipRepository = membershipRepository;
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    public List<Reservation> getReservationsByUserId(Long userId) {
        return reservationRepository.findByUserId(userId);
    }

    @Transactional
    public Reservation createReservation(Long userId, Long gymClassId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        GymClass gymClass = gymClassRepository.findById(gymClassId)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found with id: " + gymClassId));

        // Check for active membership
        membershipRepository.findByUserIdAndActiveTrue(userId)
                .orElseThrow(() -> new BadRequestException("Active membership required to make a reservation"));

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setGymClass(gymClass);
        reservation.setReservationDate(LocalDateTime.now());
        reservation.setStatus(ReservationStatus.ACTIVE);

        return reservationRepository.save(reservation);
    }

    @Transactional
    public void cancelReservation(Long id) {
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reservation not found with id: " + id));
        reservation.setStatus(ReservationStatus.CANCELLED);
        reservationRepository.save(reservation);
    }
}
