package com.gym.reservation.dto;

public class ReservationRequest {
    private Long gymClassId;

    public ReservationRequest() {}

    public ReservationRequest(Long gymClassId) {
        this.gymClassId = gymClassId;
    }

    public Long getGymClassId() { return gymClassId; }
    public void setGymClassId(Long gymClassId) { this.gymClassId = gymClassId; }
}
