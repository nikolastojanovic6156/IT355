package com.gym.reservation.controller;

import com.gym.reservation.dto.MembershipRequest;
import com.gym.reservation.entity.Membership;
import com.gym.reservation.entity.User;
import com.gym.reservation.repository.UserRepository;
import com.gym.reservation.service.MembershipService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/memberships")
public class MembershipController {

    private final MembershipService membershipService;
    private final UserRepository userRepository;

    public MembershipController(MembershipService membershipService, UserRepository userRepository) {
        this.membershipService = membershipService;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<Membership>> getMemberships(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow();

        if (authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            return ResponseEntity.ok(membershipService.getAllMemberships());
        }
        return ResponseEntity.ok(membershipService.getMembershipsByUserId(user.getId()));
    }

    @GetMapping("/active")
    public ResponseEntity<Membership> getActiveMembership(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElseThrow();
        Optional<Membership> membership = membershipService.getActiveMembershipByUserId(user.getId());
        return membership.map(ResponseEntity::ok)
                .orElse(ResponseEntity.noContent().build());
    }

    @PostMapping
    public ResponseEntity<Membership> createMembership(@RequestBody MembershipRequest request) {
        return ResponseEntity.ok(membershipService.createMembership(request));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Membership> updateMembership(@PathVariable Long id, @RequestBody Membership membership) {
        return ResponseEntity.ok(membershipService.updateMembership(id, membership));
    }
}
