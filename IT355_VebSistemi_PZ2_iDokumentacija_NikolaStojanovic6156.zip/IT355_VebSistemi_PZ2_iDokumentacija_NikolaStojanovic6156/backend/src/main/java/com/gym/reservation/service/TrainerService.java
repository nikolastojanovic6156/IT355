package com.gym.reservation.service;

import com.gym.reservation.entity.Trainer;
import com.gym.reservation.exception.ResourceNotFoundException;
import com.gym.reservation.repository.TrainerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TrainerService {

    private final TrainerRepository trainerRepository;

    public TrainerService(TrainerRepository trainerRepository) {
        this.trainerRepository = trainerRepository;
    }

    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    public Trainer getTrainerById(Long id) {
        return trainerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Trainer not found with id: " + id));
    }

    @Transactional
    public Trainer createTrainer(Trainer trainer) {
        return trainerRepository.save(trainer);
    }

    @Transactional
    public Trainer updateTrainer(Long id, Trainer trainerDetails) {
        Trainer trainer = getTrainerById(id);
        trainer.setFirstName(trainerDetails.getFirstName());
        trainer.setLastName(trainerDetails.getLastName());
        trainer.setSpecialty(trainerDetails.getSpecialty());
        trainer.setExperienceYears(trainerDetails.getExperienceYears());
        trainer.setBio(trainerDetails.getBio());
        trainer.setPhone(trainerDetails.getPhone());
        return trainerRepository.save(trainer);
    }

    @Transactional
    public void deleteTrainer(Long id) {
        Trainer trainer = getTrainerById(id);
        trainerRepository.delete(trainer);
    }
}
