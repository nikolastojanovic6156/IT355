package com.gym.reservation.dto;

import java.time.LocalDate;

public class MembershipRequest {
    private Long userId;
    private String type;
    private LocalDate startDate;

    public MembershipRequest() {}

    public MembershipRequest(Long userId, String type, LocalDate startDate) {
        this.userId = userId;
        this.type = type;
        this.startDate = startDate;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
}
