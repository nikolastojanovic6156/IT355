package com.gym.reservation.service;

import com.gym.reservation.dto.MembershipRequest;
import com.gym.reservation.entity.*;
import com.gym.reservation.exception.ResourceNotFoundException;
import com.gym.reservation.repository.MembershipRepository;
import com.gym.reservation.repository.ReservationRepository;
import com.gym.reservation.repository.UserRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class MembershipService {

    private final MembershipRepository membershipRepository;
    private final UserRepository userRepository;
    private final ReservationRepository reservationRepository;

    public MembershipService(MembershipRepository membershipRepository, UserRepository userRepository,
                             ReservationRepository reservationRepository) {
        this.membershipRepository = membershipRepository;
        this.userRepository = userRepository;
        this.reservationRepository = reservationRepository;
    }

    public List<Membership> getAllMemberships() {
        return membershipRepository.findAll();
    }

    public List<Membership> getMembershipsByUserId(Long userId) {
        return membershipRepository.findByUserId(userId);
    }

    public Optional<Membership> getActiveMembershipByUserId(Long userId) {
        return membershipRepository.findByUserIdAndActiveTrue(userId);
    }

    @Transactional
    public Membership createMembership(MembershipRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + request.getUserId()));

        MembershipType type = MembershipType.valueOf(request.getType());
        LocalDate startDate = request.getStartDate() != null ? request.getStartDate() : LocalDate.now();
        LocalDate endDate;
        double price;

        switch (type) {
            case MONTHLY:
                endDate = startDate.plusMonths(1);
                price = 3000.0;
                break;
            case QUARTERLY:
                endDate = startDate.plusMonths(3);
                price = 7500.0;
                break;
            case YEARLY:
                endDate = startDate.plusYears(1);
                price = 25000.0;
                break;
            default:
                throw new IllegalArgumentException("Invalid membership type");
        }

        Membership membership = new Membership();
        membership.setUser(user);
        membership.setType(type);
        membership.setStartDate(startDate);
        membership.setEndDate(endDate);
        membership.setActive(true);
        membership.setPrice(price);

        return membershipRepository.save(membership);
    }

    @Transactional
    public Membership updateMembership(Long id, Membership membershipDetails) {
        Membership membership = membershipRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Membership not found with id: " + id));
        membership.setType(membershipDetails.getType());
        membership.setStartDate(membershipDetails.getStartDate());
        membership.setEndDate(membershipDetails.getEndDate());
        membership.setActive(membershipDetails.getActive());
        membership.setPrice(membershipDetails.getPrice());
        return membershipRepository.save(membership);
    }

    /**
     * Scheduled task that runs every hour to check for expired memberships.
     * When a membership expires:
     * 1. Sets the membership as inactive
     * 2. Cancels all active reservations for that user
     */
    @Transactional
    @Scheduled(cron = "0 0 * * * *")
    public void checkExpiredMemberships() {
        List<Membership> expiredMemberships = membershipRepository
                .findByActiveTrueAndEndDateBefore(LocalDate.now());

        for (Membership membership : expiredMemberships) {
            membership.setActive(false);
            membershipRepository.save(membership);

            // Cancel all active reservations for this user
            List<Reservation> activeReservations = reservationRepository
                    .findByUserIdAndStatus(membership.getUser().getId(), ReservationStatus.ACTIVE);

            for (Reservation reservation : activeReservations) {
                reservation.setStatus(ReservationStatus.CANCELLED);
                reservationRepository.save(reservation);
            }

            System.out.println("Expired membership deactivated for user: " + membership.getUser().getEmail()
                    + ". Cancelled " + activeReservations.size() + " active reservations.");
        }
    }
}
