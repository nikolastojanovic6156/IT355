package com.gym.reservation.repository;

import com.gym.reservation.entity.Reservation;
import com.gym.reservation.entity.ReservationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    List<Reservation> findByUserId(Long userId);
    List<Reservation> findByGymClassId(Long gymClassId);
    List<Reservation> findByUserIdAndStatus(Long userId, ReservationStatus status);
}
