package com.gym.reservation.entity;

public enum ReservationStatus {
    ACTIVE,
    CANCELLED
}
