package com.gym.reservation.repository;

import com.gym.reservation.entity.Membership;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface MembershipRepository extends JpaRepository<Membership, Long> {
    List<Membership> findByUserId(Long userId);
    Optional<Membership> findByUserIdAndActiveTrue(Long userId);
    List<Membership> findByActiveTrueAndEndDateBefore(LocalDate date);
}
