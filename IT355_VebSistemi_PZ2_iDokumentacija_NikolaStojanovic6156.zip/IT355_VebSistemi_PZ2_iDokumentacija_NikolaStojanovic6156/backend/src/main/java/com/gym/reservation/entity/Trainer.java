package com.gym.reservation.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "trainers")
public class Trainer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private String specialty;
    private Integer experienceYears;

    @Column(length = 1000)
    private String bio;

    private String phone;

    @OneToMany(mappedBy = "trainer", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<GymClass> gymClasses = new ArrayList<>();

    public Trainer() {}

    public Trainer(String firstName, String lastName, String specialty, Integer experienceYears, String bio, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.specialty = specialty;
        this.experienceYears = experienceYears;
        this.bio = bio;
        this.phone = phone;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    public Integer getExperienceYears() { return experienceYears; }
    public void setExperienceYears(Integer experienceYears) { this.experienceYears = experienceYears; }
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public List<GymClass> getGymClasses() { return gymClasses; }
    public void setGymClasses(List<GymClass> gymClasses) { this.gymClasses = gymClasses; }
}
