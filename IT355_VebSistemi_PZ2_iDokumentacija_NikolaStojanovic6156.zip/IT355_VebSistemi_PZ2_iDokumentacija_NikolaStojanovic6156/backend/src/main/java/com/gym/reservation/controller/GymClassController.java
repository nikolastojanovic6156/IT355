package com.gym.reservation.controller;

import com.gym.reservation.entity.GymClass;
import com.gym.reservation.service.GymClassService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/classes")
public class GymClassController {

    private final GymClassService gymClassService;

    public GymClassController(GymClassService gymClassService) {
        this.gymClassService = gymClassService;
    }

    @GetMapping
    public ResponseEntity<List<GymClass>> getAllClasses() {
        return ResponseEntity.ok(gymClassService.getAllClasses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<GymClass> getClassById(@PathVariable Long id) {
        return ResponseEntity.ok(gymClassService.getClassById(id));
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<GymClass>> getClassesByCategory(@PathVariable String category) {
        return ResponseEntity.ok(gymClassService.getClassesByCategory(category));
    }

    @PostMapping
    public ResponseEntity<GymClass> createClass(@RequestBody GymClass gymClass) {
        return ResponseEntity.ok(gymClassService.createClass(gymClass));
    }

    @PutMapping("/{id}")
    public ResponseEntity<GymClass> updateClass(@PathVariable Long id, @RequestBody GymClass gymClass) {
        return ResponseEntity.ok(gymClassService.updateClass(id, gymClass));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteClass(@PathVariable Long id) {
        gymClassService.deleteClass(id);
        return ResponseEntity.ok("Class deleted successfully");
    }
}
