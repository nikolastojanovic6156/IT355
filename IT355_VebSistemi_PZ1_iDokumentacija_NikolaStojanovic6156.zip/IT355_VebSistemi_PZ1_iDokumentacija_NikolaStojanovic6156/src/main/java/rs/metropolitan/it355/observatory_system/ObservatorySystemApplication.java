package rs.metropolitan.it355.observatory_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObservatorySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObservatorySystemApplication.class, args);
	}

}
