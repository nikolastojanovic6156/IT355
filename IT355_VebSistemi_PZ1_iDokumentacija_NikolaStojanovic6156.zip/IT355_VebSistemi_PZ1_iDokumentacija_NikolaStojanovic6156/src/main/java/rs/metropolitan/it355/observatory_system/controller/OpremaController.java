package rs.metropolitan.it355.observatory_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import rs.metropolitan.it355.observatory_system.model.Oprema;
import rs.metropolitan.it355.observatory_system.model.Opservatorija;
import rs.metropolitan.it355.observatory_system.model.StatusOpreme;
import rs.metropolitan.it355.observatory_system.model.TipOpreme;
import rs.metropolitan.it355.observatory_system.service.OpservatorijaSkladiste;

@Controller
@RequestMapping("/oprema")
public class OpremaController {

    @Autowired
    private OpservatorijaSkladiste skladiste;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("pageTitle", "Inventar opreme");
        model.addAttribute("svaOprema", skladiste.getSvaOprema());
        return "oprema/list";
    }

    @GetMapping("/nova")
    public String showCreateForm(Model model) {
        model.addAttribute("pageTitle", "Dodaj opremu");
        model.addAttribute("oprema", new Oprema());
        model.addAttribute("opservatorije", skladiste.getSveOpservatorije());
        model.addAttribute("tipovi", TipOpreme.values());
        model.addAttribute("statusi", StatusOpreme.values());
        return "oprema/form";
    }

    @GetMapping("/uredi/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Oprema oprema = skladiste.getOpremaPoId(id);
        if (oprema == null) {
            return "redirect:/oprema";
        }
        model.addAttribute("pageTitle", "Izmeni opremu");
        model.addAttribute("oprema", oprema);
        model.addAttribute("opservatorije", skladiste.getSveOpservatorije());
        model.addAttribute("tipovi", TipOpreme.values());
        model.addAttribute("statusi", StatusOpreme.values());
        return "oprema/form";
    }

    @PostMapping("/sacuvaj")
    public String save(@ModelAttribute Oprema oprema, @RequestParam("opservatorijaId") Long opservatorijaId) {
        Opservatorija opservatorija = skladiste.getOpservatorijaPoId(opservatorijaId);
        oprema.setOpservatorija(opservatorija);
        skladiste.sacuvajOpremu(oprema);
        return "redirect:/oprema";
    }

    @GetMapping("/obrisi/{id}")
    public String delete(@PathVariable Long id) {
        skladiste.obrisiOpremu(id);
        return "redirect:/oprema";
    }
}
