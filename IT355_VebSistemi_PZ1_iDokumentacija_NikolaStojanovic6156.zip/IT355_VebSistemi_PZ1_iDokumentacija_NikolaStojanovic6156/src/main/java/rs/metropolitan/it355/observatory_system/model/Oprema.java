package rs.metropolitan.it355.observatory_system.model;

import java.util.Objects;

public class Oprema {
    private Long id;
    private String naziv;
    private TipOpreme tip;
    private String proizvodjac;
    private StatusOpreme status;
    private Opservatorija opservatorija;

    public Oprema() {}

    public Oprema(Long id, String naziv, TipOpreme tip, String proizvodjac, StatusOpreme status, Opservatorija opservatorija) {
        this.id = id;
        this.naziv = naziv;
        this.tip = tip;
        this.proizvodjac = proizvodjac;
        this.status = status;
        this.opservatorija = opservatorija;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public TipOpreme getTip() {
        return tip;
    }

    public void setTip(TipOpreme tip) {
        this.tip = tip;
    }

    public String getProizvodjac() {
        return proizvodjac;
    }

    public void setProizvodjac(String proizvodjac) {
        this.proizvodjac = proizvodjac;
    }

    public StatusOpreme getStatus() {
        return status;
    }

    public void setStatus(StatusOpreme status) {
        this.status = status;
    }

    public Opservatorija getOpservatorija() {
        return opservatorija;
    }

    public void setOpservatorija(Opservatorija opservatorija) {
        this.opservatorija = opservatorija;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Oprema oprema = (Oprema) o;
        return Objects.equals(id, oprema.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return naziv + " (" + tip.getPrikazanoIme() + ")";
    }
}
