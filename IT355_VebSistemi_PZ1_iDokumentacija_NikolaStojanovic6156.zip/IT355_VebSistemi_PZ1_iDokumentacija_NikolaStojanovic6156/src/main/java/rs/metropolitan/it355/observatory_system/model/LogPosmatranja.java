package rs.metropolitan.it355.observatory_system.model;

import java.util.Objects;

public class LogPosmatranja {
    private Long id;
    private Long sesijaId;
    private NebeskoTelo nebeskoTelo;
    private String vremePosmatranja; // npr. "23:15"
    private Double uvecanje;
    private String beleske;
    private Integer ocenaKvaliteta; // 1 do 5

    public LogPosmatranja() {}

    public LogPosmatranja(Long id, Long sesijaId, NebeskoTelo nebeskoTelo, String vremePosmatranja, Double uvecanje, String beleske, Integer ocenaKvaliteta) {
        this.id = id;
        this.sesijaId = sesijaId;
        this.nebeskoTelo = nebeskoTelo;
        this.vremePosmatranja = vremePosmatranja;
        this.uvecanje = uvecanje;
        this.beleske = beleske;
        this.ocenaKvaliteta = ocenaKvaliteta;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSesijaId() {
        return sesijaId;
    }

    public void setSesijaId(Long sesijaId) {
        this.sesijaId = sesijaId;
    }

    public NebeskoTelo getNebeskoTelo() {
        return nebeskoTelo;
    }

    public void setNebeskoTelo(NebeskoTelo nebeskoTelo) {
        this.nebeskoTelo = nebeskoTelo;
    }

    public String getVremePosmatranja() {
        return vremePosmatranja;
    }

    public void setVremePosmatranja(String vremePosmatranja) {
        this.vremePosmatranja = vremePosmatranja;
    }

    public Double getUvecanje() {
        return uvecanje;
    }

    public void setUvecanje(Double uvecanje) {
        this.uvecanje = uvecanje;
    }

    public String getBeleske() {
        return beleske;
    }

    public void setBeleske(String beleske) {
        this.beleske = beleske;
    }

    public Integer getOcenaKvaliteta() {
        return ocenaKvaliteta;
    }

    public void setOcenaKvaliteta(Integer ocenaKvaliteta) {
        this.ocenaKvaliteta = ocenaKvaliteta;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LogPosmatranja that = (LogPosmatranja) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Log za " + (nebeskoTelo != null ? nebeskoTelo.getNaziv() : "Nepoznato") + " u " + vremePosmatranja;
    }
}
