package rs.metropolitan.it355.observatory_system.service;

import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;
import rs.metropolitan.it355.observatory_system.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
@ApplicationScope
public class OpservatorijaSkladiste {

    private final List<Opservatorija> opservatorije = Collections.synchronizedList(new ArrayList<>());
    private final List<NebeskoTelo> nebeskaTela = Collections.synchronizedList(new ArrayList<>());
    private final List<PosmatrackaSesija> sesije = Collections.synchronizedList(new ArrayList<>());
    private final List<LogPosmatranja> logovi = Collections.synchronizedList(new ArrayList<>());
    private final List<Oprema> opremaLista = Collections.synchronizedList(new ArrayList<>());

    private final AtomicLong opservatorijaIdCounter = new AtomicLong(1);
    private final AtomicLong nebeskoTeloIdCounter = new AtomicLong(1);
    private final AtomicLong sesijaIdCounter = new AtomicLong(1);
    private final AtomicLong logIdCounter = new AtomicLong(1);
    private final AtomicLong opremaIdCounter = new AtomicLong(1);

    public OpservatorijaSkladiste() {
        popuniMockPodatke();
    }

    private void popuniMockPodatke() {
        // 1. Opservatorije
        Opservatorija o1 = new Opservatorija(
                opservatorijaIdCounter.getAndIncrement(),
                "Opservatorija Mauna Kea",
                "Havaji, SAD",
                19.8206,
                -155.4681,
                4207.0,
                "Keck dvostruki 10-metarski teleskop",
                "Smeštena na vrhu Mauna Kea, jedna od vodećih svetskih lokacija za astronomska istraživanja."
        );
        Opservatorija o2 = new Opservatorija(
                opservatorijaIdCounter.getAndIncrement(),
                "Opservatorija Ondrejov",
                "Ondrejov, Češka Republika",
                49.9149,
                14.7812,
                528.0,
                "2-metarski Zeiss reflektujući teleskop",
                "Istorijska češka opservatorija, poznata po solarnoj astronomiji i praćenju meteora."
        );
        Opservatorija o3 = new Opservatorija(
                opservatorijaIdCounter.getAndIncrement(),
                "Kraljevska opservatorija Grinič",
                "London, Velika Britanija",
                51.4778,
                -0.0015,
                68.0,
                "28-inčni Great Refractor",
                "Istorijska opservatorija koja označava nulti meridijan. Danas prvenstveno muzej i edukativni centar."
        );

        opservatorije.add(o1);
        opservatorije.add(o2);
        opservatorije.add(o3);

        // 2. Nebeska tela
        NebeskoTelo nt1 = new NebeskoTelo(
                nebeskoTeloIdCounter.getAndIncrement(),
                "Jupiter",
                TipNebeskogTela.PLANETA,
                "17h 15m 12s",
                "-22° 41' 15\"",
                -2.7,
                "Najveća planeta u našem sunčevom sistemu. Velika crvena pega i četiri Galilejeva satelita su lako vidljivi."
        );
        NebeskoTelo nt2 = new NebeskoTelo(
                nebeskoTeloIdCounter.getAndIncrement(),
                "Vega",
                TipNebeskogTela.ZVEZDA,
                "18h 36m 56s",
                "+38° 47' 01\"",
                0.03,
                "Sjajna plavo-bela zvezda u sazvežđu Lira. Jedno od temena Letnjeg trougla."
        );
        NebeskoTelo nt3 = new NebeskoTelo(
                nebeskoTeloIdCounter.getAndIncrement(),
                "Andromeda Galaksija",
                TipNebeskogTela.GALAKSIJA,
                "00h 42m 44s",
                "+41° 16' 09\"",
                3.44,
                "Poznata i kao M31. Najbliža velika galaksija našem Mlečnom putu, vidljiva golim okom pod tamnim nebom."
        );
        NebeskoTelo nt4 = new NebeskoTelo(
                nebeskoTeloIdCounter.getAndIncrement(),
                "Maglina Prsten",
                TipNebeskogTela.MAGLINA,
                "18h 53m 35s",
                "+33° 01' 45\"",
                8.8,
                "M57, planetarna maglina u Liri. Nastala od ljuske jonizovanog gasa izbačenog u okolni prostor."
        );
        NebeskoTelo nt5 = new NebeskoTelo(
                nebeskoTeloIdCounter.getAndIncrement(),
                "Halejeva kometa",
                TipNebeskogTela.KOMETA,
                "Promenljivo",
                "Promenljivo",
                28.2,
                "Najpoznatija periodična kometa, koja se vraća u unutrašnji sunčev sistem svakih 75-76 godina."
        );

        nebeskaTela.add(nt1);
        nebeskaTela.add(nt2);
        nebeskaTela.add(nt3);
        nebeskaTela.add(nt4);
        nebeskaTela.add(nt5);

        // 3. Oprema
        Oprema op1 = new Oprema(
                opremaIdCounter.getAndIncrement(),
                "Keck I Reflektor",
                TipOpreme.TELESKOP,
                "Zadužbina Keck",
                StatusOpreme.U_FUNKCIJI,
                o1
        );
        Oprema op2 = new Oprema(
                opremaIdCounter.getAndIncrement(),
                "MOSFIRE Spektrograf",
                TipOpreme.KAMERA,
                "UCLA / Caltech",
                StatusOpreme.U_FUNKCIJI,
                o1
        );
        Oprema op3 = new Oprema(
                opremaIdCounter.getAndIncrement(),
                "D20 Solarni spektroheliograf",
                TipOpreme.TELESKOP,
                "Zeiss",
                StatusOpreme.ODRZAVANJE,
                o2
        );
        Oprema op4 = new Oprema(
                opremaIdCounter.getAndIncrement(),
                "Great Refractor 28\"",
                TipOpreme.TELESKOP,
                "Grubb & Co",
                StatusOpreme.U_FUNKCIJI,
                o3
        );

        opremaLista.add(op1);
        opremaLista.add(op2);
        opremaLista.add(op3);
        opremaLista.add(op4);

        // 4. Sesije
        PosmatrackaSesija s1 = new PosmatrackaSesija(
                sesijaIdCounter.getAndIncrement(),
                LocalDate.now().minusDays(5),
                o1,
                "Dr Nikola Stojanović",
                StanjeNeba.VEDRO,
                "Veoma stabilni atmosferski uslovi. Indeks vidljivosti 8/10."
        );
        PosmatrackaSesija s2 = new PosmatrackaSesija(
                sesijaIdCounter.getAndIncrement(),
                LocalDate.now().minusDays(2),
                o2,
                "Prof. Jan Horak",
                StanjeNeba.DELIMICNO_OBLACNO,
                "Malo prolaznih oblaka na visokoj nadmorskoj visini, ali uglavnom dobra providnost."
        );

        sesije.add(s1);
        sesije.add(s2);

        // 5. Logovi
        LogPosmatranja l1 = new LogPosmatranja(
                logIdCounter.getAndIncrement(),
                s1.getId(),
                nt1,
                "22:30",
                300.0,
                "Velika crvena pega je u centru. Uočene senke tranzita Evrope i Ganimeda.",
                5
        );
        LogPosmatranja l2 = new LogPosmatranja(
                logIdCounter.getAndIncrement(),
                s1.getId(),
                nt3,
                "23:45",
                80.0,
                "Jasno vidljive trake prašine blizu jezgra galaksije. Uočeni i sateliti M32 i M110.",
                5
        );
        LogPosmatranja l3 = new LogPosmatranja(
                logIdCounter.getAndIncrement(),
                s2.getId(),
                nt2,
                "21:15",
                150.0,
                "Vega je sjajna i plavo-bela. Korišćena kao standardna zvezda za kalibraciju.",
                4
        );
        LogPosmatranja l4 = new LogPosmatranja(
                logIdCounter.getAndIncrement(),
                s2.getId(),
                nt4,
                "22:05",
                200.0,
                "Oblik krofne jasno vidljiv, centralna zvezda je veoma slaba ali detektovana.",
                3
        );

        logovi.add(l1);
        logovi.add(l2);
        logovi.add(l3);
        logovi.add(l4);
    }

    // --- OPSERVATORIJA CRUD ---
    public List<Opservatorija> getSveOpservatorije() {
        return new ArrayList<>(opservatorije);
    }

    public Opservatorija getOpservatorijaPoId(Long id) {
        return opservatorije.stream()
                .filter(o -> o.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Opservatorija sacuvajOpservatoriju(Opservatorija opservatorija) {
        if (opservatorija.getId() == null) {
            opservatorija.setId(opservatorijaIdCounter.getAndIncrement());
            opservatorije.add(opservatorija);
        } else {
            int index = opservatorije.indexOf(opservatorija);
            if (index >= 0) {
                opservatorije.set(index, opservatorija);
            }
        }
        return opservatorija;
    }

    public void obrisiOpservatoriju(Long id) {
        opservatorije.removeIf(o -> o.getId().equals(id));
        // Kaskadno: ukloni vezu u opremi
        for (Oprema op : opremaLista) {
            if (op.getOpservatorija() != null && op.getOpservatorija().getId().equals(id)) {
                op.setOpservatorija(null);
            }
        }
        // Kaskadno: ukloni vezu u sesijama
        for (PosmatrackaSesija s : sesije) {
            if (s.getOpservatorija() != null && s.getOpservatorija().getId().equals(id)) {
                s.setOpservatorija(null);
            }
        }
    }

    // --- NEBESKO TELO CRUD ---
    public List<NebeskoTelo> getSvaNebeskaTela() {
        return new ArrayList<>(nebeskaTela);
    }

    public NebeskoTelo getNebeskoTeloPoId(Long id) {
        return nebeskaTela.stream()
                .filter(nt -> nt.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public NebeskoTelo sacuvajNebeskoTelo(NebeskoTelo nebeskoTelo) {
        if (nebeskoTelo.getId() == null) {
            nebeskoTelo.setId(nebeskoTeloIdCounter.getAndIncrement());
            nebeskaTela.add(nebeskoTelo);
        } else {
            int index = nebeskaTela.indexOf(nebeskoTelo);
            if (index >= 0) {
                nebeskaTela.set(index, nebeskoTelo);
            }
        }
        return nebeskoTelo;
    }

    public void obrisiNebeskoTelo(Long id) {
        nebeskaTela.removeIf(nt -> nt.getId().equals(id));
        // Kaskadno: obriši logove koji referenciraju ovo nebesko telo
        logovi.removeIf(l -> l.getNebeskoTelo() != null && l.getNebeskoTelo().getId().equals(id));
    }

    // --- OPREMA CRUD ---
    public List<Oprema> getSvaOprema() {
        return new ArrayList<>(opremaLista);
    }

    public Oprema getOpremaPoId(Long id) {
        return opremaLista.stream()
                .filter(op -> op.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Oprema sacuvajOpremu(Oprema oprema) {
        if (oprema.getId() == null) {
            oprema.setId(opremaIdCounter.getAndIncrement());
            opremaLista.add(oprema);
        } else {
            int index = opremaLista.indexOf(oprema);
            if (index >= 0) {
                opremaLista.set(index, oprema);
            }
        }
        return oprema;
    }

    public void obrisiOpremu(Long id) {
        opremaLista.removeIf(op -> op.getId().equals(id));
    }

    // --- SESIJA CRUD ---
    public List<PosmatrackaSesija> getSveSesije() {
        return new ArrayList<>(sesije);
    }

    public PosmatrackaSesija getSesijaPoId(Long id) {
        return sesije.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public PosmatrackaSesija sacuvajSesiju(PosmatrackaSesija sesija) {
        if (sesija.getId() == null) {
            sesija.setId(sesijaIdCounter.getAndIncrement());
            sesije.add(sesija);
        } else {
            int index = sesije.indexOf(sesija);
            if (index >= 0) {
                sesije.set(index, sesija);
            }
        }
        return sesija;
    }

    public void obrisiSesiju(Long id) {
        sesije.removeIf(s -> s.getId().equals(id));
        // Kaskadno: obriši sve logove povezane sa ovom sesijom
        logovi.removeIf(l -> l.getSesijaId().equals(id));
    }

    // --- LOGS CRUD ---
    public List<LogPosmatranja> getSviLogovi() {
        return new ArrayList<>(logovi);
    }

    public List<LogPosmatranja> getLogoviZaSesiju(Long sesijaId) {
        List<LogPosmatranja> rez = new ArrayList<>();
        for (LogPosmatranja log : logovi) {
            if (log.getSesijaId().equals(sesijaId)) {
                rez.add(log);
            }
        }
        return rez;
    }

    public LogPosmatranja getLogPoId(Long id) {
        return logovi.stream()
                .filter(l -> l.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public LogPosmatranja sacuvajLog(LogPosmatranja log) {
        if (log.getId() == null) {
            log.setId(logIdCounter.getAndIncrement());
            logovi.add(log);
        } else {
            int index = logovi.indexOf(log);
            if (index >= 0) {
                logovi.set(index, log);
            }
        }
        return log;
    }

    public void obrisiLog(Long id) {
        logovi.removeIf(l -> l.getId().equals(id));
    }
}
