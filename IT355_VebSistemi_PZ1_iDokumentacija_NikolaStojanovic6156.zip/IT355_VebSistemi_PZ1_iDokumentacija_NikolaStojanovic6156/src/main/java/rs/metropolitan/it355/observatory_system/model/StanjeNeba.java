package rs.metropolitan.it355.observatory_system.model;

public enum StanjeNeba {
    VEDRO("Vedro nebo"),
    DELIMICNO_OBLACNO("Delimično oblačno"),
    OBLACNO("Oblačno"),
    POTPUNO_OBLACNO("Potpuno oblačno");

    private final String prikazanoIme;

    StanjeNeba(String prikazanoIme) {
        this.prikazanoIme = prikazanoIme;
    }

    public String getPrikazanoIme() {
        return prikazanoIme;
    }
}
