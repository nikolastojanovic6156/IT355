package rs.metropolitan.it355.observatory_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import rs.metropolitan.it355.observatory_system.model.*;
import rs.metropolitan.it355.observatory_system.service.OpservatorijaSkladiste;

@Controller
@RequestMapping("/sesije")
public class SesijaController {

    @Autowired
    private OpservatorijaSkladiste skladiste;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("pageTitle", "Sesije posmatranja");
        model.addAttribute("sesije", skladiste.getSveSesije());
        return "sesija/list";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        PosmatrackaSesija sesija = skladiste.getSesijaPoId(id);
        if (sesija == null) {
            return "redirect:/sesije";
        }
        model.addAttribute("pageTitle", "Detalji sesije");
        model.addAttribute("sesija", sesija);
        model.addAttribute("logovi", skladiste.getLogoviZaSesiju(id));
        
        // Priprema praznog objekta za gnežđenje kreiranja logova
        LogPosmatranja noviLog = new LogPosmatranja();
        noviLog.setSesijaId(id);
        model.addAttribute("noviLog", noviLog);
        model.addAttribute("nebeskaTela", skladiste.getSvaNebeskaTela());
        
        return "sesija/details";
    }

    @GetMapping("/nova")
    public String showCreateForm(Model model) {
        model.addAttribute("pageTitle", "Nova sesija");
        model.addAttribute("sesija", new PosmatrackaSesija());
        model.addAttribute("opservatorije", skladiste.getSveOpservatorije());
        model.addAttribute("stanja", StanjeNeba.values());
        return "sesija/form";
    }

    @GetMapping("/uredi/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        PosmatrackaSesija sesija = skladiste.getSesijaPoId(id);
        if (sesija == null) {
            return "redirect:/sesije";
        }
        model.addAttribute("pageTitle", "Izmeni sesiju");
        model.addAttribute("sesija", sesija);
        model.addAttribute("opservatorije", skladiste.getSveOpservatorije());
        model.addAttribute("stanja", StanjeNeba.values());
        return "sesija/form";
    }

    @PostMapping("/sacuvaj")
    public String save(@ModelAttribute PosmatrackaSesija sesija, @RequestParam("opservatorijaId") Long opservatorijaId) {
        Opservatorija opservatorija = skladiste.getOpservatorijaPoId(opservatorijaId);
        sesija.setOpservatorija(opservatorija);
        skladiste.sacuvajSesiju(sesija);
        return "redirect:/sesije";
    }

    @GetMapping("/obrisi/{id}")
    public String delete(@PathVariable Long id) {
        skladiste.obrisiSesiju(id);
        return "redirect:/sesije";
    }

    // --- UPRAVLJANJE LOGOVIMA UNUTAR SESIJE ---

    @PostMapping("/{sesijaId}/logovi/sacuvaj")
    public String saveLog(@PathVariable Long sesijaId, 
                          @ModelAttribute LogPosmatranja log, 
                          @RequestParam("nebeskoTeloId") Long nebeskoTeloId) {
        PosmatrackaSesija sesija = skladiste.getSesijaPoId(sesijaId);
        if (sesija != null) {
            NebeskoTelo nt = skladiste.getNebeskoTeloPoId(nebeskoTeloId);
            log.setSesijaId(sesijaId);
            log.setNebeskoTelo(nt);
            skladiste.sacuvajLog(log);
        }
        return "redirect:/sesije/" + sesijaId;
    }

    @GetMapping("/{sesijaId}/logovi/obrisi/{logId}")
    public String deleteLog(@PathVariable Long sesijaId, @PathVariable Long logId) {
        skladiste.obrisiLog(logId);
        return "redirect:/sesije/" + sesijaId;
    }
}
