package rs.metropolitan.it355.observatory_system.model;

public enum TipNebeskogTela {
    ZVEZDA("Zvezda"),
    PLANETA("Planeta"),
    GALAKSIJA("Galaksija"),
    MAGLINA("Maglina"),
    ASTEROID("Asteroid"),
    KOMETA("Kometa");

    private final String prikazanoIme;

    TipNebeskogTela(String prikazanoIme) {
        this.prikazanoIme = prikazanoIme;
    }

    public String getPrikazanoIme() {
        return prikazanoIme;
    }
}
