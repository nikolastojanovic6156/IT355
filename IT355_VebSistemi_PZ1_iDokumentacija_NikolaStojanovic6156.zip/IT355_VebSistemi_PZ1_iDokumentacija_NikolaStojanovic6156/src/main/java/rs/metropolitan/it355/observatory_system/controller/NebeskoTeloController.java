package rs.metropolitan.it355.observatory_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import rs.metropolitan.it355.observatory_system.model.NebeskoTelo;
import rs.metropolitan.it355.observatory_system.model.TipNebeskogTela;
import rs.metropolitan.it355.observatory_system.service.OpservatorijaSkladiste;

@Controller
@RequestMapping("/nebeska-tela")
public class NebeskoTeloController {

    @Autowired
    private OpservatorijaSkladiste skladiste;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("pageTitle", "Katalog nebeskih tela");
        model.addAttribute("nebeskaTela", skladiste.getSvaNebeskaTela());
        return "nebesko_telo/list";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        NebeskoTelo nebeskoTelo = skladiste.getNebeskoTeloPoId(id);
        if (nebeskoTelo == null) {
            return "redirect:/nebeska-tela";
        }
        model.addAttribute("pageTitle", nebeskoTelo.getNaziv());
        model.addAttribute("nebeskoTelo", nebeskoTelo);
        return "nebesko_telo/details";
    }

    @GetMapping("/novo")
    public String showCreateForm(Model model) {
        model.addAttribute("pageTitle", "Novo nebesko telo");
        model.addAttribute("nebeskoTelo", new NebeskoTelo());
        model.addAttribute("tipovi", TipNebeskogTela.values());
        return "nebesko_telo/form";
    }

    @GetMapping("/uredi/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        NebeskoTelo nebeskoTelo = skladiste.getNebeskoTeloPoId(id);
        if (nebeskoTelo == null) {
            return "redirect:/nebeska-tela";
        }
        model.addAttribute("pageTitle", "Izmeni " + nebeskoTelo.getNaziv());
        model.addAttribute("nebeskoTelo", nebeskoTelo);
        model.addAttribute("tipovi", TipNebeskogTela.values());
        return "nebesko_telo/form";
    }

    @PostMapping("/sacuvaj")
    public String save(@ModelAttribute NebeskoTelo nebeskoTelo) {
        skladiste.sacuvajNebeskoTelo(nebeskoTelo);
        return "redirect:/nebeska-tela";
    }

    @GetMapping("/obrisi/{id}")
    public String delete(@PathVariable Long id) {
        skladiste.obrisiNebeskoTelo(id);
        return "redirect:/nebeska-tela";
    }
}
