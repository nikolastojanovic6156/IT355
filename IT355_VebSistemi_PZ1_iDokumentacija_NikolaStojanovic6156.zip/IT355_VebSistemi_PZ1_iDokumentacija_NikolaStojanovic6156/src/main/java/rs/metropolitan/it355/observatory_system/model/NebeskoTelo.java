package rs.metropolitan.it355.observatory_system.model;

import java.util.Objects;

public class NebeskoTelo {
    private Long id;
    private String naziv;
    private TipNebeskogTela tip;
    private String rektascenzija; // npr. "18h 36m 56s"
    private String deklinacija;    // npr. "+38° 47' 01\""
    private Double prividnaMagnituda; // sjaj
    private String opis;

    public NebeskoTelo() {}

    public NebeskoTelo(Long id, String naziv, TipNebeskogTela tip, String rektascenzija, String deklinacija, Double prividnaMagnituda, String opis) {
        this.id = id;
        this.naziv = naziv;
        this.tip = tip;
        this.rektascenzija = rektascenzija;
        this.deklinacija = deklinacija;
        this.prividnaMagnituda = prividnaMagnituda;
        this.opis = opis;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public TipNebeskogTela getTip() {
        return tip;
    }

    public void setTip(TipNebeskogTela tip) {
        this.tip = tip;
    }

    public String getRektascenzija() {
        return rektascenzija;
    }

    public void setRektascenzija(String rektascenzija) {
        this.rektascenzija = rektascenzija;
    }

    public String getDeklinacija() {
        return deklinacija;
    }

    public void setDeklinacija(String deklinacija) {
        this.deklinacija = deklinacija;
    }

    public Double getPrividnaMagnituda() {
        return prividnaMagnituda;
    }

    public void setPrividnaMagnituda(Double prividnaMagnituda) {
        this.prividnaMagnituda = prividnaMagnituda;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NebeskoTelo that = (NebeskoTelo) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return naziv + " (" + tip.getPrikazanoIme() + ")";
    }
}
