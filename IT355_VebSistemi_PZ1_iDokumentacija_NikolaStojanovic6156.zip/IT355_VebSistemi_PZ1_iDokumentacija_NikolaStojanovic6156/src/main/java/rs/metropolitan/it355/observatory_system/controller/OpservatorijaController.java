package rs.metropolitan.it355.observatory_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import rs.metropolitan.it355.observatory_system.model.Opservatorija;
import rs.metropolitan.it355.observatory_system.service.OpservatorijaSkladiste;

import java.util.stream.Collectors;

@Controller
@RequestMapping("/opservatorije")
public class OpservatorijaController {

    @Autowired
    private OpservatorijaSkladiste skladiste;

    @GetMapping
    public String list(Model model) {
        model.addAttribute("pageTitle", "Opservatorije");
        model.addAttribute("opservatorije", skladiste.getSveOpservatorije());
        return "opservatorija/list";
    }

    @GetMapping("/{id}")
    public String details(@PathVariable Long id, Model model) {
        Opservatorija opservatorija = skladiste.getOpservatorijaPoId(id);
        if (opservatorija == null) {
            return "redirect:/opservatorije";
        }
        model.addAttribute("pageTitle", opservatorija.getNaziv());
        model.addAttribute("opservatorija", opservatorija);
        model.addAttribute("oprema", skladiste.getSvaOprema().stream()
                .filter(o -> o.getOpservatorija() != null && o.getOpservatorija().getId().equals(id))
                .collect(Collectors.toList()));
        return "opservatorija/details";
    }

    @GetMapping("/nova")
    public String showCreateForm(Model model) {
        model.addAttribute("pageTitle", "Nova opservatorija");
        model.addAttribute("opservatorija", new Opservatorija());
        return "opservatorija/form";
    }

    @GetMapping("/uredi/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Opservatorija opservatorija = skladiste.getOpservatorijaPoId(id);
        if (opservatorija == null) {
            return "redirect:/opservatorije";
        }
        model.addAttribute("pageTitle", "Izmeni " + opservatorija.getNaziv());
        model.addAttribute("opservatorija", opservatorija);
        return "opservatorija/form";
    }

    @PostMapping("/sacuvaj")
    public String save(@ModelAttribute Opservatorija opservatorija) {
        skladiste.sacuvajOpservatoriju(opservatorija);
        return "redirect:/opservatorije";
    }

    @GetMapping("/obrisi/{id}")
    public String delete(@PathVariable Long id) {
        skladiste.obrisiOpservatoriju(id);
        return "redirect:/opservatorije";
    }
}
