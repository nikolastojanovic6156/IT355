package rs.metropolitan.it355.observatory_system.model;

import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import java.util.Objects;

public class PosmatrackaSesija {
    private Long id;
    
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate datum;
    
    private Opservatorija opservatorija;
    private String imePosmatraca;
    private StanjeNeba stanjeNeba;
    private String beleske;

    public PosmatrackaSesija() {}

    public PosmatrackaSesija(Long id, LocalDate datum, Opservatorija opservatorija, String imePosmatraca, StanjeNeba stanjeNeba, String beleske) {
        this.id = id;
        this.datum = datum;
        this.opservatorija = opservatorija;
        this.imePosmatraca = imePosmatraca;
        this.stanjeNeba = stanjeNeba;
        this.beleske = beleske;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public Opservatorija getOpservatorija() {
        return opservatorija;
    }

    public void setOpservatorija(Opservatorija opservatorija) {
        this.opservatorija = opservatorija;
    }

    public String getImePosmatraca() {
        return imePosmatraca;
    }

    public void setImePosmatraca(String imePosmatraca) {
        this.imePosmatraca = imePosmatraca;
    }

    public StanjeNeba getStanjeNeba() {
        return stanjeNeba;
    }

    public void setStanjeNeba(StanjeNeba stanjeNeba) {
        this.stanjeNeba = stanjeNeba;
    }

    public String getBeleske() {
        return beleske;
    }

    public void setBeleske(String beleske) {
        this.beleske = beleske;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PosmatrackaSesija that = (PosmatrackaSesija) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Sesija #" + id + " dana " + datum + " u " + (opservatorija != null ? opservatorija.getNaziv() : "Nepoznato");
    }
}
