package rs.metropolitan.it355.observatory_system.model;

import java.util.Objects;

public class Opservatorija {
    private Long id;
    private String naziv;
    private String lokacija;
    private Double geografskaSirina;
    private Double geografskaDuzina;
    private Double nadmorskaVisina;
    private String modelTeleskopa;
    private String opis;

    public Opservatorija() {}

    public Opservatorija(Long id, String naziv, String lokacija, Double geografskaSirina, Double geografskaDuzina, Double nadmorskaVisina, String modelTeleskopa, String opis) {
        this.id = id;
        this.naziv = naziv;
        this.lokacija = lokacija;
        this.geografskaSirina = geografskaSirina;
        this.geografskaDuzina = geografskaDuzina;
        this.nadmorskaVisina = nadmorskaVisina;
        this.modelTeleskopa = modelTeleskopa;
        this.opis = opis;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public Double getGeografskaSirina() {
        return geografskaSirina;
    }

    public void setGeografskaSirina(Double geografskaSirina) {
        this.geografskaSirina = geografskaSirina;
    }

    public Double getGeografskaDuzina() {
        return geografskaDuzina;
    }

    public void setGeografskaDuzina(Double geografskaDuzina) {
        this.geografskaDuzina = geografskaDuzina;
    }

    public Double getNadmorskaVisina() {
        return nadmorskaVisina;
    }

    public void setNadmorskaVisina(Double nadmorskaVisina) {
        this.nadmorskaVisina = nadmorskaVisina;
    }

    public String getModelTeleskopa() {
        return modelTeleskopa;
    }

    public void setModelTeleskopa(String modelTeleskopa) {
        this.modelTeleskopa = modelTeleskopa;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Opservatorija that = (Opservatorija) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return naziv + " (" + lokacija + ")";
    }
}
