package rs.metropolitan.it355.observatory_system.model;

public enum StatusOpreme {
    U_FUNKCIJI("U funkciji"),
    ODRZAVANJE("U toku održavanja"),
    POVUCENO("Povučeno iz upotrebe");

    private final String prikazanoIme;

    StatusOpreme(String prikazanoIme) {
        this.prikazanoIme = prikazanoIme;
    }

    public String getPrikazanoIme() {
        return prikazanoIme;
    }
}
