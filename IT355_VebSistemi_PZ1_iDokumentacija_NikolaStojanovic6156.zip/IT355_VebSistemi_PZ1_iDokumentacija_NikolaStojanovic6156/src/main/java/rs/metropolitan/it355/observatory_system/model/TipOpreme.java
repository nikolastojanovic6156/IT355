package rs.metropolitan.it355.observatory_system.model;

public enum TipOpreme {
    TELESKOP("Teleskop"),
    KAMERA("Kamera"),
    FILTER("Filter"),
    OKULAR("Okular"),
    MONTAZA("Montaža");

    private final String prikazanoIme;

    TipOpreme(String prikazanoIme) {
        this.prikazanoIme = prikazanoIme;
    }

    public String getPrikazanoIme() {
        return prikazanoIme;
    }
}
