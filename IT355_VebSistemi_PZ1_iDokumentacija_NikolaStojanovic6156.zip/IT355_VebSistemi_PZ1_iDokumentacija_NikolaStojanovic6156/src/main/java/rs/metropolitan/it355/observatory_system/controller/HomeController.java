package rs.metropolitan.it355.observatory_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import rs.metropolitan.it355.observatory_system.service.OpservatorijaSkladiste;

@Controller
public class HomeController {

    @Autowired
    private OpservatorijaSkladiste skladiste;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("pageTitle", "Kontrolna tabla");
        model.addAttribute("ukupnoOpservatorija", skladiste.getSveOpservatorije().size());
        model.addAttribute("ukupnoNebeskihTela", skladiste.getSvaNebeskaTela().size());
        model.addAttribute("ukupnoSesija", skladiste.getSveSesije().size());
        model.addAttribute("ukupnoOpreme", skladiste.getSvaOprema().size());
        model.addAttribute("nedavneSesije", skladiste.getSveSesije());
        model.addAttribute("nedavniLogovi", skladiste.getSviLogovi());
        return "index";
    }
}
