package rs.metropolitan.it355.observatory_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObservatorySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
